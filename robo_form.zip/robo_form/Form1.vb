#Region "imports"
Imports System.Data
Imports System.Data.OleDb
Imports il_ve_ilce
Imports il_ve_ilce.turkiye
Imports System.Xml
Imports System.IO
#End Region
Public Class Form1
    Inherits System.Windows.Forms.Form
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.

        Me.WindowState = FormWindowState.Minimized
        InitializeComponent()
        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtad As System.Windows.Forms.TextBox
    Friend WithEvents txtikinciad As System.Windows.Forms.TextBox
    Friend WithEvents txtsoyad As System.Windows.Forms.TextBox
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents txtaltemail As System.Windows.Forms.TextBox
    Friend WithEvents txtprofiladi As System.Windows.Forms.TextBox
    Friend WithEvents txtdogumtarihi As System.Windows.Forms.TextBox
    Friend WithEvents txtyas As System.Windows.Forms.TextBox
    Friend WithEvents txtmd As System.Windows.Forms.TextBox
    Friend WithEvents txtcinsiyet As System.Windows.Forms.TextBox
    Friend WithEvents txtevtelefonu As System.Windows.Forms.TextBox
    Friend WithEvents txtistelefonu As System.Windows.Forms.TextBox
    Friend WithEvents txthobi As System.Windows.Forms.TextBox
    Friend WithEvents txtozgecmis As System.Windows.Forms.TextBox
    Friend WithEvents btntemizle As System.Windows.Forms.Button
    Friend WithEvents btnkaydet As System.Windows.Forms.Button
    Friend WithEvents btntab As System.Windows.Forms.Button
    Friend WithEvents btnenter As System.Windows.Forms.Button
    Friend WithEvents btnsil As System.Windows.Forms.Button
    Friend WithEvents btndegistir As System.Windows.Forms.Button
    Friend WithEvents cmbprofil As System.Windows.Forms.ComboBox
    Friend WithEvents lb1 As System.Windows.Forms.ListBox
    Friend WithEvents nodi As System.Windows.Forms.NotifyIcon
    Friend WithEvents ContextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents cb1 As System.Windows.Forms.CheckBox
    Friend WithEvents cb2 As System.Windows.Forms.CheckBox
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtextra3 As System.Windows.Forms.TextBox
    Friend WithEvents txtextra2 As System.Windows.Forms.TextBox
    Friend WithEvents txtextra1 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtisadres As System.Windows.Forms.TextBox
    Friend WithEvents txtevadres As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtnickname As System.Windows.Forms.TextBox
    Friend WithEvents txtsifre As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtpostakodu As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtgsc As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtgizlisoru As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtilcekodu As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtilce As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtsehirkodu As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtsehir As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtulkekodu As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtulke As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents txtunvan As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents txtmeslek As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents txttelefon As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtfaks As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents txtcagri As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents txtyahooid As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents txtmsnid As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents txticqno As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents txtvergikim As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents txtgelir As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents txtsuruculis As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents txtwebsayfam As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents cmbil As System.Windows.Forms.ComboBox
    Friend WithEvents cmbilce As System.Windows.Forms.ComboBox
    Friend WithEvents chkdiger As System.Windows.Forms.CheckBox
    Friend WithEvents txtdigerdogyer As System.Windows.Forms.TextBox
    Friend WithEvents txtsirketadi As System.Windows.Forms.TextBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents txtbolum As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents txtwebsitesi As System.Windows.Forms.TextBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents txtucrtelefon As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents txtsirverid As System.Windows.Forms.TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents txtsirkayno As System.Windows.Forms.TextBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents txtstoksim As System.Windows.Forms.TextBox
    Friend WithEvents txtsantralno As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents txtsirhakkinda As System.Windows.Forms.TextBox
    Friend WithEvents txtadresdiger As System.Windows.Forms.TextBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents cmbkartturu As System.Windows.Forms.ComboBox
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents txtfaizorani As System.Windows.Forms.TextBox
    Friend WithEvents txtkredilimiti As System.Windows.Forms.TextBox
    Friend WithEvents txtpinkodu As System.Windows.Forms.TextBox
    Friend WithEvents txtgenelserno As System.Windows.Forms.TextBox
    Friend WithEvents txtbankatelefonu As System.Windows.Forms.TextBox
    Friend WithEvents txtdagiticibanka As System.Windows.Forms.TextBox
    Friend WithEvents txtkartkuladi As System.Windows.Forms.TextBox
    Friend WithEvents txtkartno As System.Windows.Forms.TextBox
    Friend WithEvents txtonaykod As System.Windows.Forms.TextBox
    Friend WithEvents txtsurebitimi As System.Windows.Forms.TextBox
    Friend WithEvents txtgecerlilik As System.Windows.Forms.TextBox
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents txtbankpincode As System.Windows.Forms.TextBox
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents txthesapsahibi As System.Windows.Forms.TextBox
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents txtswift As System.Windows.Forms.TextBox
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents txtbanksube As System.Windows.Forms.TextBox
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents txtbanktel As System.Windows.Forms.TextBox
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents txtyolno As System.Windows.Forms.TextBox
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents txthesapno As System.Windows.Forms.TextBox
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents txtbankaadi As System.Windows.Forms.TextBox
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents cmbhesapturu As System.Windows.Forms.ComboBox
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents txtbankfaiz As System.Windows.Forms.TextBox
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents txtextra4 As System.Windows.Forms.TextBox
    Friend WithEvents txtextra5 As System.Windows.Forms.TextBox
    Friend WithEvents txtextra6 As System.Windows.Forms.TextBox
    Friend WithEvents txtextra10 As System.Windows.Forms.TextBox
    Friend WithEvents txtextra11 As System.Windows.Forms.TextBox
    Friend WithEvents txtextra12 As System.Windows.Forms.TextBox
    Friend WithEvents txtextra7 As System.Windows.Forms.TextBox
    Friend WithEvents txtextra8 As System.Windows.Forms.TextBox
    Friend WithEvents txtextra9 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents lb2 As System.Windows.Forms.ListBox
    Friend WithEvents lb3 As System.Windows.Forms.ListBox
    Friend WithEvents TabControl3 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage11 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage12 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage13 As System.Windows.Forms.TabPage
    Friend WithEvents lb4 As System.Windows.Forms.ListBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem12 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.TabControl3 = New System.Windows.Forms.TabControl
        Me.TabPage10 = New System.Windows.Forms.TabPage
        Me.lb1 = New System.Windows.Forms.ListBox
        Me.TabPage11 = New System.Windows.Forms.TabPage
        Me.lb2 = New System.Windows.Forms.ListBox
        Me.TabPage12 = New System.Windows.Forms.TabPage
        Me.lb3 = New System.Windows.Forms.ListBox
        Me.TabPage13 = New System.Windows.Forms.TabPage
        Me.lb4 = New System.Windows.Forms.ListBox
        Me.cb2 = New System.Windows.Forms.CheckBox
        Me.cb1 = New System.Windows.Forms.CheckBox
        Me.btnenter = New System.Windows.Forms.Button
        Me.btntab = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmbprofil = New System.Windows.Forms.ComboBox
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.TabControl2 = New System.Windows.Forms.TabControl
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label43 = New System.Windows.Forms.Label
        Me.txtwebsayfam = New System.Windows.Forms.TextBox
        Me.Label42 = New System.Windows.Forms.Label
        Me.txtsuruculis = New System.Windows.Forms.TextBox
        Me.Label41 = New System.Windows.Forms.Label
        Me.txtgelir = New System.Windows.Forms.TextBox
        Me.Label40 = New System.Windows.Forms.Label
        Me.txtvergikim = New System.Windows.Forms.TextBox
        Me.Label39 = New System.Windows.Forms.Label
        Me.txticqno = New System.Windows.Forms.TextBox
        Me.Label37 = New System.Windows.Forms.Label
        Me.txtyahooid = New System.Windows.Forms.TextBox
        Me.Label38 = New System.Windows.Forms.Label
        Me.txtmsnid = New System.Windows.Forms.TextBox
        Me.Label36 = New System.Windows.Forms.Label
        Me.txtcagri = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.txtfaks = New System.Windows.Forms.TextBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.txttelefon = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.txtistelefonu = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.txtevtelefonu = New System.Windows.Forms.TextBox
        Me.txtaltemail = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtemail = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtdigerdogyer = New System.Windows.Forms.TextBox
        Me.chkdiger = New System.Windows.Forms.CheckBox
        Me.cmbilce = New System.Windows.Forms.ComboBox
        Me.cmbil = New System.Windows.Forms.ComboBox
        Me.Label45 = New System.Windows.Forms.Label
        Me.Label44 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.txtmeslek = New System.Windows.Forms.TextBox
        Me.Label32 = New System.Windows.Forms.Label
        Me.txtunvan = New System.Windows.Forms.TextBox
        Me.txtikinciad = New System.Windows.Forms.TextBox
        Me.txtcinsiyet = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtyas = New System.Windows.Forms.TextBox
        Me.txtmd = New System.Windows.Forms.TextBox
        Me.txtprofiladi = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtdogumtarihi = New System.Windows.Forms.TextBox
        Me.txtad = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtsoyad = New System.Windows.Forms.TextBox
        Me.TabPage6 = New System.Windows.Forms.TabPage
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.cmbkartturu = New System.Windows.Forms.ComboBox
        Me.txtkartkuladi = New System.Windows.Forms.TextBox
        Me.Label62 = New System.Windows.Forms.Label
        Me.txtdagiticibanka = New System.Windows.Forms.TextBox
        Me.Label61 = New System.Windows.Forms.Label
        Me.txtbankatelefonu = New System.Windows.Forms.TextBox
        Me.Label60 = New System.Windows.Forms.Label
        Me.txtgenelserno = New System.Windows.Forms.TextBox
        Me.Label59 = New System.Windows.Forms.Label
        Me.Label64 = New System.Windows.Forms.Label
        Me.Label65 = New System.Windows.Forms.Label
        Me.Label66 = New System.Windows.Forms.Label
        Me.txtonaykod = New System.Windows.Forms.TextBox
        Me.txtfaizorani = New System.Windows.Forms.TextBox
        Me.Label56 = New System.Windows.Forms.Label
        Me.Label67 = New System.Windows.Forms.Label
        Me.txtgecerlilik = New System.Windows.Forms.TextBox
        Me.txtkartno = New System.Windows.Forms.TextBox
        Me.txtsurebitimi = New System.Windows.Forms.TextBox
        Me.txtpinkodu = New System.Windows.Forms.TextBox
        Me.Label58 = New System.Windows.Forms.Label
        Me.txtkredilimiti = New System.Windows.Forms.TextBox
        Me.Label57 = New System.Windows.Forms.Label
        Me.Label63 = New System.Windows.Forms.Label
        Me.TabPage4 = New System.Windows.Forms.TabPage
        Me.Label54 = New System.Windows.Forms.Label
        Me.txtsirhakkinda = New System.Windows.Forms.TextBox
        Me.txtsantralno = New System.Windows.Forms.TextBox
        Me.Label53 = New System.Windows.Forms.Label
        Me.txtstoksim = New System.Windows.Forms.TextBox
        Me.txtsirverid = New System.Windows.Forms.TextBox
        Me.Label51 = New System.Windows.Forms.Label
        Me.txtsirkayno = New System.Windows.Forms.TextBox
        Me.Label52 = New System.Windows.Forms.Label
        Me.txtwebsitesi = New System.Windows.Forms.TextBox
        Me.Label49 = New System.Windows.Forms.Label
        Me.txtucrtelefon = New System.Windows.Forms.TextBox
        Me.Label50 = New System.Windows.Forms.Label
        Me.txtbolum = New System.Windows.Forms.TextBox
        Me.Label48 = New System.Windows.Forms.Label
        Me.Label47 = New System.Windows.Forms.Label
        Me.txtsirketadi = New System.Windows.Forms.TextBox
        Me.Label46 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.txthobi = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.txtozgecmis = New System.Windows.Forms.TextBox
        Me.TabPage5 = New System.Windows.Forms.TabPage
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.txtsehirkodu = New System.Windows.Forms.TextBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.txtilcekodu = New System.Windows.Forms.TextBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.txtilce = New System.Windows.Forms.TextBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.txtsehir = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.txtulkekodu = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.txtulke = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.txtpostakodu = New System.Windows.Forms.TextBox
        Me.txtadresdiger = New System.Windows.Forms.TextBox
        Me.Label55 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.txtisadres = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.txtevadres = New System.Windows.Forms.TextBox
        Me.TabPage7 = New System.Windows.Forms.TabPage
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.Label73 = New System.Windows.Forms.Label
        Me.cmbhesapturu = New System.Windows.Forms.ComboBox
        Me.Label77 = New System.Windows.Forms.Label
        Me.txtbankfaiz = New System.Windows.Forms.TextBox
        Me.txtbankaadi = New System.Windows.Forms.TextBox
        Me.Label74 = New System.Windows.Forms.Label
        Me.txthesapno = New System.Windows.Forms.TextBox
        Me.Label75 = New System.Windows.Forms.Label
        Me.Label76 = New System.Windows.Forms.Label
        Me.Label69 = New System.Windows.Forms.Label
        Me.txtbankpincode = New System.Windows.Forms.TextBox
        Me.Label68 = New System.Windows.Forms.Label
        Me.txthesapsahibi = New System.Windows.Forms.TextBox
        Me.Label70 = New System.Windows.Forms.Label
        Me.txtbanktel = New System.Windows.Forms.TextBox
        Me.txtswift = New System.Windows.Forms.TextBox
        Me.Label71 = New System.Windows.Forms.Label
        Me.txtbanksube = New System.Windows.Forms.TextBox
        Me.Label72 = New System.Windows.Forms.Label
        Me.txtyolno = New System.Windows.Forms.TextBox
        Me.TabPage8 = New System.Windows.Forms.TabPage
        Me.txtextra10 = New System.Windows.Forms.TextBox
        Me.txtextra11 = New System.Windows.Forms.TextBox
        Me.txtextra12 = New System.Windows.Forms.TextBox
        Me.Label81 = New System.Windows.Forms.Label
        Me.Label82 = New System.Windows.Forms.Label
        Me.Label83 = New System.Windows.Forms.Label
        Me.txtextra7 = New System.Windows.Forms.TextBox
        Me.txtextra8 = New System.Windows.Forms.TextBox
        Me.txtextra9 = New System.Windows.Forms.TextBox
        Me.Label84 = New System.Windows.Forms.Label
        Me.Label85 = New System.Windows.Forms.Label
        Me.Label86 = New System.Windows.Forms.Label
        Me.txtextra4 = New System.Windows.Forms.TextBox
        Me.txtextra5 = New System.Windows.Forms.TextBox
        Me.txtextra6 = New System.Windows.Forms.TextBox
        Me.Label78 = New System.Windows.Forms.Label
        Me.Label79 = New System.Windows.Forms.Label
        Me.Label80 = New System.Windows.Forms.Label
        Me.txtextra1 = New System.Windows.Forms.TextBox
        Me.txtextra2 = New System.Windows.Forms.TextBox
        Me.txtextra3 = New System.Windows.Forms.TextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.TabPage9 = New System.Windows.Forms.TabPage
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.txtgsc = New System.Windows.Forms.TextBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.txtgizlisoru = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtnickname = New System.Windows.Forms.TextBox
        Me.txtsifre = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.btndegistir = New System.Windows.Forms.Button
        Me.btnsil = New System.Windows.Forms.Button
        Me.btnkaydet = New System.Windows.Forms.Button
        Me.btntemizle = New System.Windows.Forms.Button
        Me.nodi = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.ContextMenu1 = New System.Windows.Forms.ContextMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.MenuItem11 = New System.Windows.Forms.MenuItem
        Me.MenuItem12 = New System.Windows.Forms.MenuItem
        Me.MenuItem8 = New System.Windows.Forms.MenuItem
        Me.MenuItem9 = New System.Windows.Forms.MenuItem
        Me.MenuItem10 = New System.Windows.Forms.MenuItem
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TabControl1.Location = New System.Drawing.Point(0, 20)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(644, 457)
        Me.TabControl1.TabIndex = 100
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TabControl3)
        Me.TabPage1.Controls.Add(Me.cb2)
        Me.TabPage1.Controls.Add(Me.cb1)
        Me.TabPage1.Controls.Add(Me.btnenter)
        Me.TabPage1.Controls.Add(Me.btntab)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.cmbprofil)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(636, 431)
        Me.TabPage1.TabIndex = 0
        '
        'TabControl3
        '
        Me.TabControl3.Controls.Add(Me.TabPage10)
        Me.TabControl3.Controls.Add(Me.TabPage11)
        Me.TabControl3.Controls.Add(Me.TabPage12)
        Me.TabControl3.Controls.Add(Me.TabPage13)
        Me.TabControl3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TabControl3.Location = New System.Drawing.Point(0, 59)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(636, 372)
        Me.TabControl3.TabIndex = 103
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.lb1)
        Me.TabPage10.Location = New System.Drawing.Point(4, 22)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Size = New System.Drawing.Size(628, 346)
        Me.TabPage10.TabIndex = 0
        '
        'lb1
        '
        Me.lb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lb1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lb1.Location = New System.Drawing.Point(0, 0)
        Me.lb1.Name = "lb1"
        Me.lb1.Size = New System.Drawing.Size(628, 340)
        Me.lb1.TabIndex = 5
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.lb2)
        Me.TabPage11.Location = New System.Drawing.Point(4, 22)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Size = New System.Drawing.Size(628, 346)
        Me.TabPage11.TabIndex = 1
        '
        'lb2
        '
        Me.lb2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lb2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lb2.Location = New System.Drawing.Point(0, 0)
        Me.lb2.Name = "lb2"
        Me.lb2.Size = New System.Drawing.Size(628, 346)
        Me.lb2.TabIndex = 101
        '
        'TabPage12
        '
        Me.TabPage12.Controls.Add(Me.lb3)
        Me.TabPage12.Location = New System.Drawing.Point(4, 22)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Size = New System.Drawing.Size(628, 346)
        Me.TabPage12.TabIndex = 2
        '
        'lb3
        '
        Me.lb3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lb3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lb3.Location = New System.Drawing.Point(0, 0)
        Me.lb3.Name = "lb3"
        Me.lb3.Size = New System.Drawing.Size(628, 346)
        Me.lb3.TabIndex = 102
        '
        'TabPage13
        '
        Me.TabPage13.Controls.Add(Me.lb4)
        Me.TabPage13.Location = New System.Drawing.Point(4, 22)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Size = New System.Drawing.Size(628, 346)
        Me.TabPage13.TabIndex = 3
        '
        'lb4
        '
        Me.lb4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lb4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lb4.Location = New System.Drawing.Point(0, 0)
        Me.lb4.Name = "lb4"
        Me.lb4.Size = New System.Drawing.Size(628, 346)
        Me.lb4.TabIndex = 6
        '
        'cb2
        '
        Me.cb2.Location = New System.Drawing.Point(456, 32)
        Me.cb2.Name = "cb2"
        Me.cb2.Size = New System.Drawing.Size(128, 24)
        Me.cb2.TabIndex = 4
        Me.cb2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cb1
        '
        Me.cb1.Checked = True
        Me.cb1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cb1.Location = New System.Drawing.Point(456, 8)
        Me.cb1.Name = "cb1"
        Me.cb1.Size = New System.Drawing.Size(128, 24)
        Me.cb1.TabIndex = 3
        Me.cb1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnenter
        '
        Me.btnenter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnenter.Location = New System.Drawing.Point(360, 8)
        Me.btnenter.Name = "btnenter"
        Me.btnenter.Size = New System.Drawing.Size(64, 23)
        Me.btnenter.TabIndex = 2
        '
        'btntab
        '
        Me.btntab.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btntab.Location = New System.Drawing.Point(288, 8)
        Me.btntab.Name = "btntab"
        Me.btntab.Size = New System.Drawing.Size(64, 23)
        Me.btntab.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 23)
        Me.Label1.TabIndex = 100
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbprofil
        '
        Me.cmbprofil.Location = New System.Drawing.Point(96, 8)
        Me.cmbprofil.Name = "cmbprofil"
        Me.cmbprofil.Size = New System.Drawing.Size(184, 21)
        Me.cmbprofil.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.TabControl2)
        Me.TabPage2.Controls.Add(Me.btndegistir)
        Me.TabPage2.Controls.Add(Me.btnsil)
        Me.TabPage2.Controls.Add(Me.btnkaydet)
        Me.TabPage2.Controls.Add(Me.btntemizle)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(636, 431)
        Me.TabPage2.TabIndex = 1
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage3)
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Controls.Add(Me.TabPage4)
        Me.TabControl2.Controls.Add(Me.TabPage5)
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Controls.Add(Me.TabPage8)
        Me.TabControl2.Controls.Add(Me.TabPage9)
        Me.TabControl2.Dock = System.Windows.Forms.DockStyle.Top
        Me.TabControl2.Location = New System.Drawing.Point(0, 0)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(636, 396)
        Me.TabControl2.TabIndex = 40
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox2)
        Me.TabPage3.Controls.Add(Me.GroupBox1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(628, 370)
        Me.TabPage3.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label43)
        Me.GroupBox2.Controls.Add(Me.txtwebsayfam)
        Me.GroupBox2.Controls.Add(Me.Label42)
        Me.GroupBox2.Controls.Add(Me.txtsuruculis)
        Me.GroupBox2.Controls.Add(Me.Label41)
        Me.GroupBox2.Controls.Add(Me.txtgelir)
        Me.GroupBox2.Controls.Add(Me.Label40)
        Me.GroupBox2.Controls.Add(Me.txtvergikim)
        Me.GroupBox2.Controls.Add(Me.Label39)
        Me.GroupBox2.Controls.Add(Me.txticqno)
        Me.GroupBox2.Controls.Add(Me.Label37)
        Me.GroupBox2.Controls.Add(Me.txtyahooid)
        Me.GroupBox2.Controls.Add(Me.Label38)
        Me.GroupBox2.Controls.Add(Me.txtmsnid)
        Me.GroupBox2.Controls.Add(Me.Label36)
        Me.GroupBox2.Controls.Add(Me.txtcagri)
        Me.GroupBox2.Controls.Add(Me.Label35)
        Me.GroupBox2.Controls.Add(Me.txtfaks)
        Me.GroupBox2.Controls.Add(Me.Label34)
        Me.GroupBox2.Controls.Add(Me.txttelefon)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.txtistelefonu)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.txtevtelefonu)
        Me.GroupBox2.Controls.Add(Me.txtaltemail)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.txtemail)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Location = New System.Drawing.Point(300, 8)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(296, 356)
        Me.GroupBox2.TabIndex = 33
        Me.GroupBox2.TabStop = False
        '
        'Label43
        '
        Me.Label43.Location = New System.Drawing.Point(12, 136)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(128, 23)
        Me.Label43.TabIndex = 50
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtwebsayfam
        '
        Me.txtwebsayfam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtwebsayfam.Location = New System.Drawing.Point(144, 136)
        Me.txtwebsayfam.Name = "txtwebsayfam"
        Me.txtwebsayfam.Size = New System.Drawing.Size(140, 20)
        Me.txtwebsayfam.TabIndex = 19
        Me.txtwebsayfam.Text = ""
        '
        'Label42
        '
        Me.Label42.Location = New System.Drawing.Point(12, 328)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(128, 20)
        Me.Label42.TabIndex = 48
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtsuruculis
        '
        Me.txtsuruculis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsuruculis.Location = New System.Drawing.Point(144, 328)
        Me.txtsuruculis.Name = "txtsuruculis"
        Me.txtsuruculis.Size = New System.Drawing.Size(140, 20)
        Me.txtsuruculis.TabIndex = 27
        Me.txtsuruculis.Text = ""
        '
        'Label41
        '
        Me.Label41.Location = New System.Drawing.Point(12, 304)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(128, 20)
        Me.Label41.TabIndex = 46
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtgelir
        '
        Me.txtgelir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtgelir.Location = New System.Drawing.Point(144, 304)
        Me.txtgelir.Name = "txtgelir"
        Me.txtgelir.Size = New System.Drawing.Size(140, 20)
        Me.txtgelir.TabIndex = 26
        Me.txtgelir.Text = ""
        '
        'Label40
        '
        Me.Label40.Location = New System.Drawing.Point(12, 280)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(128, 20)
        Me.Label40.TabIndex = 44
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtvergikim
        '
        Me.txtvergikim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtvergikim.Location = New System.Drawing.Point(144, 280)
        Me.txtvergikim.Name = "txtvergikim"
        Me.txtvergikim.Size = New System.Drawing.Size(140, 20)
        Me.txtvergikim.TabIndex = 25
        Me.txtvergikim.Text = ""
        '
        'Label39
        '
        Me.Label39.Location = New System.Drawing.Point(12, 256)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(128, 20)
        Me.Label39.TabIndex = 42
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txticqno
        '
        Me.txticqno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txticqno.Location = New System.Drawing.Point(144, 256)
        Me.txticqno.Name = "txticqno"
        Me.txticqno.Size = New System.Drawing.Size(140, 20)
        Me.txticqno.TabIndex = 24
        Me.txticqno.Text = ""
        '
        'Label37
        '
        Me.Label37.Location = New System.Drawing.Point(12, 232)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(128, 20)
        Me.Label37.TabIndex = 40
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtyahooid
        '
        Me.txtyahooid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtyahooid.Location = New System.Drawing.Point(144, 232)
        Me.txtyahooid.Name = "txtyahooid"
        Me.txtyahooid.Size = New System.Drawing.Size(140, 20)
        Me.txtyahooid.TabIndex = 23
        Me.txtyahooid.Text = ""
        '
        'Label38
        '
        Me.Label38.Location = New System.Drawing.Point(12, 208)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(128, 20)
        Me.Label38.TabIndex = 38
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtmsnid
        '
        Me.txtmsnid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtmsnid.Location = New System.Drawing.Point(144, 208)
        Me.txtmsnid.Name = "txtmsnid"
        Me.txtmsnid.Size = New System.Drawing.Size(140, 20)
        Me.txtmsnid.TabIndex = 22
        Me.txtmsnid.Text = ""
        '
        'Label36
        '
        Me.Label36.Location = New System.Drawing.Point(12, 112)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(128, 23)
        Me.Label36.TabIndex = 36
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtcagri
        '
        Me.txtcagri.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtcagri.Location = New System.Drawing.Point(144, 112)
        Me.txtcagri.Name = "txtcagri"
        Me.txtcagri.Size = New System.Drawing.Size(140, 20)
        Me.txtcagri.TabIndex = 18
        Me.txtcagri.Text = ""
        '
        'Label35
        '
        Me.Label35.Location = New System.Drawing.Point(12, 88)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(128, 23)
        Me.Label35.TabIndex = 34
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtfaks
        '
        Me.txtfaks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtfaks.Location = New System.Drawing.Point(144, 88)
        Me.txtfaks.Name = "txtfaks"
        Me.txtfaks.Size = New System.Drawing.Size(140, 20)
        Me.txtfaks.TabIndex = 17
        Me.txtfaks.Text = ""
        '
        'Label34
        '
        Me.Label34.Location = New System.Drawing.Point(12, 16)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(128, 23)
        Me.Label34.TabIndex = 32
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txttelefon
        '
        Me.txttelefon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txttelefon.Location = New System.Drawing.Point(144, 16)
        Me.txttelefon.Name = "txttelefon"
        Me.txttelefon.Size = New System.Drawing.Size(140, 20)
        Me.txttelefon.TabIndex = 14
        Me.txttelefon.Text = ""
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(12, 64)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(128, 23)
        Me.Label17.TabIndex = 30
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtistelefonu
        '
        Me.txtistelefonu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtistelefonu.Location = New System.Drawing.Point(144, 64)
        Me.txtistelefonu.Name = "txtistelefonu"
        Me.txtistelefonu.Size = New System.Drawing.Size(140, 20)
        Me.txtistelefonu.TabIndex = 16
        Me.txtistelefonu.Text = ""
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(12, 40)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(128, 23)
        Me.Label16.TabIndex = 28
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtevtelefonu
        '
        Me.txtevtelefonu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtevtelefonu.Location = New System.Drawing.Point(144, 40)
        Me.txtevtelefonu.Name = "txtevtelefonu"
        Me.txtevtelefonu.Size = New System.Drawing.Size(140, 20)
        Me.txtevtelefonu.TabIndex = 15
        Me.txtevtelefonu.Text = ""
        '
        'txtaltemail
        '
        Me.txtaltemail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtaltemail.Location = New System.Drawing.Point(144, 184)
        Me.txtaltemail.Name = "txtaltemail"
        Me.txtaltemail.Size = New System.Drawing.Size(140, 20)
        Me.txtaltemail.TabIndex = 21
        Me.txtaltemail.Text = ""
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(12, 184)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(128, 23)
        Me.Label8.TabIndex = 12
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtemail
        '
        Me.txtemail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtemail.Location = New System.Drawing.Point(144, 160)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(140, 20)
        Me.txtemail.TabIndex = 20
        Me.txtemail.Text = ""
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(12, 160)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(128, 23)
        Me.Label7.TabIndex = 10
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtdigerdogyer)
        Me.GroupBox1.Controls.Add(Me.chkdiger)
        Me.GroupBox1.Controls.Add(Me.cmbilce)
        Me.GroupBox1.Controls.Add(Me.cmbil)
        Me.GroupBox1.Controls.Add(Me.Label45)
        Me.GroupBox1.Controls.Add(Me.Label44)
        Me.GroupBox1.Controls.Add(Me.Label33)
        Me.GroupBox1.Controls.Add(Me.txtmeslek)
        Me.GroupBox1.Controls.Add(Me.Label32)
        Me.GroupBox1.Controls.Add(Me.txtunvan)
        Me.GroupBox1.Controls.Add(Me.txtikinciad)
        Me.GroupBox1.Controls.Add(Me.txtcinsiyet)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.txtyas)
        Me.GroupBox1.Controls.Add(Me.txtmd)
        Me.GroupBox1.Controls.Add(Me.txtprofiladi)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.txtdogumtarihi)
        Me.GroupBox1.Controls.Add(Me.txtad)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtsoyad)
        Me.GroupBox1.Location = New System.Drawing.Point(4, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(296, 356)
        Me.GroupBox1.TabIndex = 32
        Me.GroupBox1.TabStop = False
        '
        'txtdigerdogyer
        '
        Me.txtdigerdogyer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdigerdogyer.Enabled = False
        Me.txtdigerdogyer.Location = New System.Drawing.Point(172, 312)
        Me.txtdigerdogyer.Name = "txtdigerdogyer"
        Me.txtdigerdogyer.Size = New System.Drawing.Size(112, 20)
        Me.txtdigerdogyer.TabIndex = 13
        Me.txtdigerdogyer.Text = ""
        '
        'chkdiger
        '
        Me.chkdiger.Checked = True
        Me.chkdiger.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkdiger.Location = New System.Drawing.Point(12, 312)
        Me.chkdiger.Name = "chkdiger"
        Me.chkdiger.Size = New System.Drawing.Size(156, 36)
        Me.chkdiger.TabIndex = 12
        '
        'cmbilce
        '
        Me.cmbilce.Location = New System.Drawing.Point(144, 284)
        Me.cmbilce.Name = "cmbilce"
        Me.cmbilce.Size = New System.Drawing.Size(140, 21)
        Me.cmbilce.TabIndex = 11
        '
        'cmbil
        '
        Me.cmbil.Location = New System.Drawing.Point(144, 256)
        Me.cmbil.Name = "cmbil"
        Me.cmbil.Size = New System.Drawing.Size(140, 21)
        Me.cmbil.TabIndex = 10
        '
        'Label45
        '
        Me.Label45.Location = New System.Drawing.Point(12, 280)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(128, 23)
        Me.Label45.TabIndex = 37
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label44
        '
        Me.Label44.Location = New System.Drawing.Point(12, 256)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(128, 23)
        Me.Label44.TabIndex = 36
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label33
        '
        Me.Label33.Location = New System.Drawing.Point(12, 136)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(128, 23)
        Me.Label33.TabIndex = 34
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtmeslek
        '
        Me.txtmeslek.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtmeslek.Location = New System.Drawing.Point(144, 136)
        Me.txtmeslek.Name = "txtmeslek"
        Me.txtmeslek.Size = New System.Drawing.Size(140, 20)
        Me.txtmeslek.TabIndex = 5
        Me.txtmeslek.Text = ""
        '
        'Label32
        '
        Me.Label32.Location = New System.Drawing.Point(12, 112)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(128, 23)
        Me.Label32.TabIndex = 32
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtunvan
        '
        Me.txtunvan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtunvan.Location = New System.Drawing.Point(144, 112)
        Me.txtunvan.Name = "txtunvan"
        Me.txtunvan.Size = New System.Drawing.Size(140, 20)
        Me.txtunvan.TabIndex = 4
        Me.txtunvan.Text = ""
        '
        'txtikinciad
        '
        Me.txtikinciad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtikinciad.Location = New System.Drawing.Point(144, 64)
        Me.txtikinciad.Name = "txtikinciad"
        Me.txtikinciad.Size = New System.Drawing.Size(140, 20)
        Me.txtikinciad.TabIndex = 2
        Me.txtikinciad.Text = ""
        '
        'txtcinsiyet
        '
        Me.txtcinsiyet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtcinsiyet.Location = New System.Drawing.Point(144, 232)
        Me.txtcinsiyet.Name = "txtcinsiyet"
        Me.txtcinsiyet.Size = New System.Drawing.Size(140, 20)
        Me.txtcinsiyet.TabIndex = 9
        Me.txtcinsiyet.Text = ""
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(12, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(128, 23)
        Me.Label3.TabIndex = 2
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(12, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(128, 23)
        Me.Label4.TabIndex = 4
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(12, 232)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(128, 23)
        Me.Label13.TabIndex = 22
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtyas
        '
        Me.txtyas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtyas.Location = New System.Drawing.Point(144, 184)
        Me.txtyas.Name = "txtyas"
        Me.txtyas.Size = New System.Drawing.Size(140, 20)
        Me.txtyas.TabIndex = 7
        Me.txtyas.Text = ""
        '
        'txtmd
        '
        Me.txtmd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtmd.Location = New System.Drawing.Point(144, 208)
        Me.txtmd.Name = "txtmd"
        Me.txtmd.Size = New System.Drawing.Size(140, 20)
        Me.txtmd.TabIndex = 8
        Me.txtmd.Text = ""
        '
        'txtprofiladi
        '
        Me.txtprofiladi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtprofiladi.Location = New System.Drawing.Point(144, 16)
        Me.txtprofiladi.Name = "txtprofiladi"
        Me.txtprofiladi.Size = New System.Drawing.Size(140, 20)
        Me.txtprofiladi.TabIndex = 0
        Me.txtprofiladi.Text = ""
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(12, 160)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(128, 23)
        Me.Label10.TabIndex = 16
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(12, 208)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(128, 23)
        Me.Label12.TabIndex = 20
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(12, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(128, 23)
        Me.Label9.TabIndex = 14
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(12, 184)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(128, 23)
        Me.Label11.TabIndex = 18
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtdogumtarihi
        '
        Me.txtdogumtarihi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdogumtarihi.Location = New System.Drawing.Point(144, 160)
        Me.txtdogumtarihi.Name = "txtdogumtarihi"
        Me.txtdogumtarihi.Size = New System.Drawing.Size(140, 20)
        Me.txtdogumtarihi.TabIndex = 6
        Me.txtdogumtarihi.Text = ""
        '
        'txtad
        '
        Me.txtad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtad.Location = New System.Drawing.Point(144, 40)
        Me.txtad.Name = "txtad"
        Me.txtad.Size = New System.Drawing.Size(140, 20)
        Me.txtad.TabIndex = 1
        Me.txtad.Text = ""
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(12, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 23)
        Me.Label2.TabIndex = 0
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtsoyad
        '
        Me.txtsoyad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsoyad.Location = New System.Drawing.Point(144, 88)
        Me.txtsoyad.Name = "txtsoyad"
        Me.txtsoyad.Size = New System.Drawing.Size(140, 20)
        Me.txtsoyad.TabIndex = 3
        Me.txtsoyad.Text = ""
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.GroupBox4)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(628, 370)
        Me.TabPage6.TabIndex = 3
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.cmbkartturu)
        Me.GroupBox4.Controls.Add(Me.txtkartkuladi)
        Me.GroupBox4.Controls.Add(Me.Label62)
        Me.GroupBox4.Controls.Add(Me.txtdagiticibanka)
        Me.GroupBox4.Controls.Add(Me.Label61)
        Me.GroupBox4.Controls.Add(Me.txtbankatelefonu)
        Me.GroupBox4.Controls.Add(Me.Label60)
        Me.GroupBox4.Controls.Add(Me.txtgenelserno)
        Me.GroupBox4.Controls.Add(Me.Label59)
        Me.GroupBox4.Controls.Add(Me.Label64)
        Me.GroupBox4.Controls.Add(Me.Label65)
        Me.GroupBox4.Controls.Add(Me.Label66)
        Me.GroupBox4.Controls.Add(Me.txtonaykod)
        Me.GroupBox4.Controls.Add(Me.txtfaizorani)
        Me.GroupBox4.Controls.Add(Me.Label56)
        Me.GroupBox4.Controls.Add(Me.Label67)
        Me.GroupBox4.Controls.Add(Me.txtgecerlilik)
        Me.GroupBox4.Controls.Add(Me.txtkartno)
        Me.GroupBox4.Controls.Add(Me.txtsurebitimi)
        Me.GroupBox4.Controls.Add(Me.txtpinkodu)
        Me.GroupBox4.Controls.Add(Me.Label58)
        Me.GroupBox4.Controls.Add(Me.txtkredilimiti)
        Me.GroupBox4.Controls.Add(Me.Label57)
        Me.GroupBox4.Controls.Add(Me.Label63)
        Me.GroupBox4.Location = New System.Drawing.Point(100, 12)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(408, 340)
        Me.GroupBox4.TabIndex = 81
        Me.GroupBox4.TabStop = False
        '
        'cmbkartturu
        '
        Me.cmbkartturu.Items.AddRange(New Object() {"Visa", "Master Cart", "American Express", "Carte Bleue", "CB", "Diners Club", "Discover", "JCB", "Delta", "Solo", "Switch"})
        Me.cmbkartturu.Location = New System.Drawing.Point(196, 32)
        Me.cmbkartturu.Name = "cmbkartturu"
        Me.cmbkartturu.Size = New System.Drawing.Size(192, 21)
        Me.cmbkartturu.TabIndex = 0
        '
        'txtkartkuladi
        '
        Me.txtkartkuladi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtkartkuladi.Location = New System.Drawing.Point(196, 152)
        Me.txtkartkuladi.Name = "txtkartkuladi"
        Me.txtkartkuladi.Size = New System.Drawing.Size(192, 20)
        Me.txtkartkuladi.TabIndex = 5
        Me.txtkartkuladi.Text = ""
        '
        'Label62
        '
        Me.Label62.Location = New System.Drawing.Point(16, 152)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(176, 23)
        Me.Label62.TabIndex = 57
        Me.Label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtdagiticibanka
        '
        Me.txtdagiticibanka.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtdagiticibanka.Location = New System.Drawing.Point(196, 176)
        Me.txtdagiticibanka.Name = "txtdagiticibanka"
        Me.txtdagiticibanka.Size = New System.Drawing.Size(192, 20)
        Me.txtdagiticibanka.TabIndex = 6
        Me.txtdagiticibanka.Text = ""
        '
        'Label61
        '
        Me.Label61.Location = New System.Drawing.Point(16, 176)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(176, 23)
        Me.Label61.TabIndex = 59
        Me.Label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtbankatelefonu
        '
        Me.txtbankatelefonu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbankatelefonu.Location = New System.Drawing.Point(196, 200)
        Me.txtbankatelefonu.Name = "txtbankatelefonu"
        Me.txtbankatelefonu.Size = New System.Drawing.Size(192, 20)
        Me.txtbankatelefonu.TabIndex = 7
        Me.txtbankatelefonu.Text = ""
        '
        'Label60
        '
        Me.Label60.Location = New System.Drawing.Point(16, 200)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(176, 23)
        Me.Label60.TabIndex = 62
        Me.Label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtgenelserno
        '
        Me.txtgenelserno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtgenelserno.Location = New System.Drawing.Point(196, 224)
        Me.txtgenelserno.Name = "txtgenelserno"
        Me.txtgenelserno.Size = New System.Drawing.Size(192, 20)
        Me.txtgenelserno.TabIndex = 8
        Me.txtgenelserno.Text = ""
        '
        'Label59
        '
        Me.Label59.Location = New System.Drawing.Point(16, 224)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(176, 23)
        Me.Label59.TabIndex = 64
        Me.Label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label64
        '
        Me.Label64.Location = New System.Drawing.Point(16, 56)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(176, 23)
        Me.Label64.TabIndex = 73
        Me.Label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label65
        '
        Me.Label65.Location = New System.Drawing.Point(16, 80)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(176, 23)
        Me.Label65.TabIndex = 75
        Me.Label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label66
        '
        Me.Label66.Location = New System.Drawing.Point(16, 104)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(176, 23)
        Me.Label66.TabIndex = 77
        Me.Label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtonaykod
        '
        Me.txtonaykod.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtonaykod.Location = New System.Drawing.Point(196, 80)
        Me.txtonaykod.Name = "txtonaykod"
        Me.txtonaykod.Size = New System.Drawing.Size(192, 20)
        Me.txtonaykod.TabIndex = 2
        Me.txtonaykod.Text = ""
        '
        'txtfaizorani
        '
        Me.txtfaizorani.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtfaizorani.Location = New System.Drawing.Point(196, 296)
        Me.txtfaizorani.Name = "txtfaizorani"
        Me.txtfaizorani.Size = New System.Drawing.Size(192, 20)
        Me.txtfaizorani.TabIndex = 11
        Me.txtfaizorani.Text = ""
        '
        'Label56
        '
        Me.Label56.Location = New System.Drawing.Point(16, 296)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(176, 23)
        Me.Label56.TabIndex = 70
        Me.Label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label67
        '
        Me.Label67.Location = New System.Drawing.Point(16, 128)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(176, 23)
        Me.Label67.TabIndex = 79
        Me.Label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtgecerlilik
        '
        Me.txtgecerlilik.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtgecerlilik.Location = New System.Drawing.Point(196, 128)
        Me.txtgecerlilik.Name = "txtgecerlilik"
        Me.txtgecerlilik.Size = New System.Drawing.Size(192, 20)
        Me.txtgecerlilik.TabIndex = 4
        Me.txtgecerlilik.Text = ""
        '
        'txtkartno
        '
        Me.txtkartno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtkartno.Location = New System.Drawing.Point(196, 56)
        Me.txtkartno.Name = "txtkartno"
        Me.txtkartno.Size = New System.Drawing.Size(192, 20)
        Me.txtkartno.TabIndex = 1
        Me.txtkartno.Text = ""
        '
        'txtsurebitimi
        '
        Me.txtsurebitimi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsurebitimi.Location = New System.Drawing.Point(196, 104)
        Me.txtsurebitimi.Name = "txtsurebitimi"
        Me.txtsurebitimi.Size = New System.Drawing.Size(192, 20)
        Me.txtsurebitimi.TabIndex = 3
        Me.txtsurebitimi.Text = ""
        '
        'txtpinkodu
        '
        Me.txtpinkodu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpinkodu.Location = New System.Drawing.Point(196, 248)
        Me.txtpinkodu.Name = "txtpinkodu"
        Me.txtpinkodu.Size = New System.Drawing.Size(192, 20)
        Me.txtpinkodu.TabIndex = 9
        Me.txtpinkodu.Text = ""
        '
        'Label58
        '
        Me.Label58.Location = New System.Drawing.Point(16, 248)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(176, 23)
        Me.Label58.TabIndex = 66
        Me.Label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtkredilimiti
        '
        Me.txtkredilimiti.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtkredilimiti.Location = New System.Drawing.Point(196, 272)
        Me.txtkredilimiti.Name = "txtkredilimiti"
        Me.txtkredilimiti.Size = New System.Drawing.Size(192, 20)
        Me.txtkredilimiti.TabIndex = 10
        Me.txtkredilimiti.Text = ""
        '
        'Label57
        '
        Me.Label57.Location = New System.Drawing.Point(16, 272)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(176, 23)
        Me.Label57.TabIndex = 68
        Me.Label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label63
        '
        Me.Label63.Location = New System.Drawing.Point(16, 32)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(176, 23)
        Me.Label63.TabIndex = 72
        Me.Label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Label54)
        Me.TabPage4.Controls.Add(Me.txtsirhakkinda)
        Me.TabPage4.Controls.Add(Me.txtsantralno)
        Me.TabPage4.Controls.Add(Me.Label53)
        Me.TabPage4.Controls.Add(Me.txtstoksim)
        Me.TabPage4.Controls.Add(Me.txtsirverid)
        Me.TabPage4.Controls.Add(Me.Label51)
        Me.TabPage4.Controls.Add(Me.txtsirkayno)
        Me.TabPage4.Controls.Add(Me.Label52)
        Me.TabPage4.Controls.Add(Me.txtwebsitesi)
        Me.TabPage4.Controls.Add(Me.Label49)
        Me.TabPage4.Controls.Add(Me.txtucrtelefon)
        Me.TabPage4.Controls.Add(Me.Label50)
        Me.TabPage4.Controls.Add(Me.txtbolum)
        Me.TabPage4.Controls.Add(Me.Label48)
        Me.TabPage4.Controls.Add(Me.Label47)
        Me.TabPage4.Controls.Add(Me.txtsirketadi)
        Me.TabPage4.Controls.Add(Me.Label46)
        Me.TabPage4.Controls.Add(Me.Label27)
        Me.TabPage4.Controls.Add(Me.txthobi)
        Me.TabPage4.Controls.Add(Me.Label28)
        Me.TabPage4.Controls.Add(Me.txtozgecmis)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(628, 370)
        Me.TabPage4.TabIndex = 1
        '
        'Label54
        '
        Me.Label54.Location = New System.Drawing.Point(112, 208)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(172, 23)
        Me.Label54.TabIndex = 70
        Me.Label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtsirhakkinda
        '
        Me.txtsirhakkinda.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsirhakkinda.Location = New System.Drawing.Point(288, 204)
        Me.txtsirhakkinda.Multiline = True
        Me.txtsirhakkinda.Name = "txtsirhakkinda"
        Me.txtsirhakkinda.Size = New System.Drawing.Size(220, 48)
        Me.txtsirhakkinda.TabIndex = 8
        Me.txtsirhakkinda.Text = ""
        '
        'txtsantralno
        '
        Me.txtsantralno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsantralno.Location = New System.Drawing.Point(288, 80)
        Me.txtsantralno.Name = "txtsantralno"
        Me.txtsantralno.Size = New System.Drawing.Size(220, 20)
        Me.txtsantralno.TabIndex = 3
        Me.txtsantralno.Text = ""
        '
        'Label53
        '
        Me.Label53.Location = New System.Drawing.Point(112, 80)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(172, 23)
        Me.Label53.TabIndex = 67
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtstoksim
        '
        Me.txtstoksim.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtstoksim.Location = New System.Drawing.Point(288, 176)
        Me.txtstoksim.Name = "txtstoksim"
        Me.txtstoksim.Size = New System.Drawing.Size(220, 20)
        Me.txtstoksim.TabIndex = 7
        Me.txtstoksim.Text = ""
        '
        'txtsirverid
        '
        Me.txtsirverid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsirverid.Location = New System.Drawing.Point(288, 152)
        Me.txtsirverid.Name = "txtsirverid"
        Me.txtsirverid.Size = New System.Drawing.Size(220, 20)
        Me.txtsirverid.TabIndex = 6
        Me.txtsirverid.Text = ""
        '
        'Label51
        '
        Me.Label51.Location = New System.Drawing.Point(112, 152)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(172, 23)
        Me.Label51.TabIndex = 64
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtsirkayno
        '
        Me.txtsirkayno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsirkayno.Location = New System.Drawing.Point(288, 128)
        Me.txtsirkayno.Name = "txtsirkayno"
        Me.txtsirkayno.Size = New System.Drawing.Size(220, 20)
        Me.txtsirkayno.TabIndex = 5
        Me.txtsirkayno.Text = ""
        '
        'Label52
        '
        Me.Label52.Location = New System.Drawing.Point(112, 176)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(172, 23)
        Me.Label52.TabIndex = 62
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtwebsitesi
        '
        Me.txtwebsitesi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtwebsitesi.Location = New System.Drawing.Point(288, 104)
        Me.txtwebsitesi.Name = "txtwebsitesi"
        Me.txtwebsitesi.Size = New System.Drawing.Size(220, 20)
        Me.txtwebsitesi.TabIndex = 4
        Me.txtwebsitesi.Text = ""
        '
        'Label49
        '
        Me.Label49.Location = New System.Drawing.Point(112, 104)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(172, 23)
        Me.Label49.TabIndex = 60
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtucrtelefon
        '
        Me.txtucrtelefon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtucrtelefon.Location = New System.Drawing.Point(288, 56)
        Me.txtucrtelefon.Name = "txtucrtelefon"
        Me.txtucrtelefon.Size = New System.Drawing.Size(220, 20)
        Me.txtucrtelefon.TabIndex = 2
        Me.txtucrtelefon.Text = ""
        '
        'Label50
        '
        Me.Label50.Location = New System.Drawing.Point(112, 56)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(172, 23)
        Me.Label50.TabIndex = 58
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtbolum
        '
        Me.txtbolum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbolum.Location = New System.Drawing.Point(288, 32)
        Me.txtbolum.Name = "txtbolum"
        Me.txtbolum.Size = New System.Drawing.Size(220, 20)
        Me.txtbolum.TabIndex = 1
        Me.txtbolum.Text = ""
        '
        'Label48
        '
        Me.Label48.Location = New System.Drawing.Point(112, 32)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(172, 23)
        Me.Label48.TabIndex = 56
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label47
        '
        Me.Label47.Location = New System.Drawing.Point(112, 128)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(172, 23)
        Me.Label47.TabIndex = 55
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtsirketadi
        '
        Me.txtsirketadi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsirketadi.Location = New System.Drawing.Point(288, 8)
        Me.txtsirketadi.Name = "txtsirketadi"
        Me.txtsirketadi.Size = New System.Drawing.Size(220, 20)
        Me.txtsirketadi.TabIndex = 0
        Me.txtsirketadi.Text = ""
        '
        'Label46
        '
        Me.Label46.Location = New System.Drawing.Point(112, 8)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(172, 23)
        Me.Label46.TabIndex = 53
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label27
        '
        Me.Label27.Location = New System.Drawing.Point(112, 268)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(172, 23)
        Me.Label27.TabIndex = 50
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txthobi
        '
        Me.txthobi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txthobi.Location = New System.Drawing.Point(288, 260)
        Me.txthobi.Multiline = True
        Me.txthobi.Name = "txthobi"
        Me.txthobi.Size = New System.Drawing.Size(220, 48)
        Me.txthobi.TabIndex = 9
        Me.txthobi.Text = ""
        '
        'Label28
        '
        Me.Label28.Location = New System.Drawing.Point(112, 320)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(172, 23)
        Me.Label28.TabIndex = 52
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtozgecmis
        '
        Me.txtozgecmis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtozgecmis.Location = New System.Drawing.Point(288, 316)
        Me.txtozgecmis.Multiline = True
        Me.txtozgecmis.Name = "txtozgecmis"
        Me.txtozgecmis.Size = New System.Drawing.Size(220, 48)
        Me.txtozgecmis.TabIndex = 10
        Me.txtozgecmis.Text = ""
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.GroupBox3)
        Me.TabPage5.Controls.Add(Me.txtadresdiger)
        Me.TabPage5.Controls.Add(Me.Label55)
        Me.TabPage5.Controls.Add(Me.Label14)
        Me.TabPage5.Controls.Add(Me.txtisadres)
        Me.TabPage5.Controls.Add(Me.Label15)
        Me.TabPage5.Controls.Add(Me.txtevadres)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(628, 370)
        Me.TabPage5.TabIndex = 2
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtsehirkodu)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.Label24)
        Me.GroupBox3.Controls.Add(Me.txtilcekodu)
        Me.GroupBox3.Controls.Add(Me.Label23)
        Me.GroupBox3.Controls.Add(Me.txtilce)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Controls.Add(Me.txtsehir)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.txtulkekodu)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.txtulke)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.txtpostakodu)
        Me.GroupBox3.Location = New System.Drawing.Point(136, 172)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(332, 192)
        Me.GroupBox3.TabIndex = 59
        Me.GroupBox3.TabStop = False
        '
        'txtsehirkodu
        '
        Me.txtsehirkodu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsehirkodu.Location = New System.Drawing.Point(124, 112)
        Me.txtsehirkodu.Name = "txtsehirkodu"
        Me.txtsehirkodu.Size = New System.Drawing.Size(192, 20)
        Me.txtsehirkodu.TabIndex = 7
        Me.txtsehirkodu.Text = ""
        '
        'Label22
        '
        Me.Label22.Location = New System.Drawing.Point(16, 112)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(104, 23)
        Me.Label22.TabIndex = 52
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(16, 160)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(104, 23)
        Me.Label24.TabIndex = 56
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtilcekodu
        '
        Me.txtilcekodu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtilcekodu.Location = New System.Drawing.Point(124, 160)
        Me.txtilcekodu.Name = "txtilcekodu"
        Me.txtilcekodu.Size = New System.Drawing.Size(192, 20)
        Me.txtilcekodu.TabIndex = 9
        Me.txtilcekodu.Text = ""
        '
        'Label23
        '
        Me.Label23.Location = New System.Drawing.Point(16, 136)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(104, 23)
        Me.Label23.TabIndex = 54
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtilce
        '
        Me.txtilce.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtilce.Location = New System.Drawing.Point(124, 136)
        Me.txtilce.Name = "txtilce"
        Me.txtilce.Size = New System.Drawing.Size(192, 20)
        Me.txtilce.TabIndex = 8
        Me.txtilce.Text = ""
        '
        'Label21
        '
        Me.Label21.Location = New System.Drawing.Point(16, 88)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(104, 23)
        Me.Label21.TabIndex = 50
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtsehir
        '
        Me.txtsehir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsehir.Location = New System.Drawing.Point(124, 88)
        Me.txtsehir.Name = "txtsehir"
        Me.txtsehir.Size = New System.Drawing.Size(192, 20)
        Me.txtsehir.TabIndex = 6
        Me.txtsehir.Text = ""
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(16, 64)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(104, 23)
        Me.Label20.TabIndex = 48
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtulkekodu
        '
        Me.txtulkekodu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtulkekodu.Location = New System.Drawing.Point(124, 64)
        Me.txtulkekodu.Name = "txtulkekodu"
        Me.txtulkekodu.Size = New System.Drawing.Size(192, 20)
        Me.txtulkekodu.TabIndex = 5
        Me.txtulkekodu.Text = ""
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(16, 40)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(104, 23)
        Me.Label19.TabIndex = 45
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtulke
        '
        Me.txtulke.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtulke.Location = New System.Drawing.Point(124, 40)
        Me.txtulke.Name = "txtulke"
        Me.txtulke.Size = New System.Drawing.Size(192, 20)
        Me.txtulke.TabIndex = 4
        Me.txtulke.Text = ""
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(16, 16)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(104, 23)
        Me.Label18.TabIndex = 34
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtpostakodu
        '
        Me.txtpostakodu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtpostakodu.Location = New System.Drawing.Point(124, 16)
        Me.txtpostakodu.Name = "txtpostakodu"
        Me.txtpostakodu.Size = New System.Drawing.Size(192, 20)
        Me.txtpostakodu.TabIndex = 3
        Me.txtpostakodu.Text = ""
        '
        'txtadresdiger
        '
        Me.txtadresdiger.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtadresdiger.Location = New System.Drawing.Point(168, 116)
        Me.txtadresdiger.Multiline = True
        Me.txtadresdiger.Name = "txtadresdiger"
        Me.txtadresdiger.Size = New System.Drawing.Size(428, 48)
        Me.txtadresdiger.TabIndex = 2
        Me.txtadresdiger.Text = ""
        '
        'Label55
        '
        Me.Label55.Location = New System.Drawing.Point(8, 120)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(152, 23)
        Me.Label55.TabIndex = 58
        Me.Label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(8, 8)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(152, 23)
        Me.Label14.TabIndex = 28
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtisadres
        '
        Me.txtisadres.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtisadres.Location = New System.Drawing.Point(168, 60)
        Me.txtisadres.Multiline = True
        Me.txtisadres.Name = "txtisadres"
        Me.txtisadres.Size = New System.Drawing.Size(428, 48)
        Me.txtisadres.TabIndex = 1
        Me.txtisadres.Text = ""
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(8, 64)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(152, 23)
        Me.Label15.TabIndex = 31
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtevadres
        '
        Me.txtevadres.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtevadres.Location = New System.Drawing.Point(168, 4)
        Me.txtevadres.Multiline = True
        Me.txtevadres.Name = "txtevadres"
        Me.txtevadres.Size = New System.Drawing.Size(428, 48)
        Me.txtevadres.TabIndex = 0
        Me.txtevadres.Text = ""
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.GroupBox5)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(628, 370)
        Me.TabPage7.TabIndex = 4
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label73)
        Me.GroupBox5.Controls.Add(Me.cmbhesapturu)
        Me.GroupBox5.Controls.Add(Me.Label77)
        Me.GroupBox5.Controls.Add(Me.txtbankfaiz)
        Me.GroupBox5.Controls.Add(Me.txtbankaadi)
        Me.GroupBox5.Controls.Add(Me.Label74)
        Me.GroupBox5.Controls.Add(Me.txthesapno)
        Me.GroupBox5.Controls.Add(Me.Label75)
        Me.GroupBox5.Controls.Add(Me.Label76)
        Me.GroupBox5.Controls.Add(Me.Label69)
        Me.GroupBox5.Controls.Add(Me.txtbankpincode)
        Me.GroupBox5.Controls.Add(Me.Label68)
        Me.GroupBox5.Controls.Add(Me.txthesapsahibi)
        Me.GroupBox5.Controls.Add(Me.Label70)
        Me.GroupBox5.Controls.Add(Me.txtbanktel)
        Me.GroupBox5.Controls.Add(Me.txtswift)
        Me.GroupBox5.Controls.Add(Me.Label71)
        Me.GroupBox5.Controls.Add(Me.txtbanksube)
        Me.GroupBox5.Controls.Add(Me.Label72)
        Me.GroupBox5.Controls.Add(Me.txtyolno)
        Me.GroupBox5.Location = New System.Drawing.Point(88, 40)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(420, 296)
        Me.GroupBox5.TabIndex = 91
        Me.GroupBox5.TabStop = False
        '
        'Label73
        '
        Me.Label73.Location = New System.Drawing.Point(24, 104)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(176, 23)
        Me.Label73.TabIndex = 71
        Me.Label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbhesapturu
        '
        Me.cmbhesapturu.Location = New System.Drawing.Point(200, 80)
        Me.cmbhesapturu.Name = "cmbhesapturu"
        Me.cmbhesapturu.Size = New System.Drawing.Size(192, 21)
        Me.cmbhesapturu.TabIndex = 2
        '
        'Label77
        '
        Me.Label77.Location = New System.Drawing.Point(24, 200)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(176, 23)
        Me.Label77.TabIndex = 90
        Me.Label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtbankfaiz
        '
        Me.txtbankfaiz.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbankfaiz.Location = New System.Drawing.Point(200, 200)
        Me.txtbankfaiz.Name = "txtbankfaiz"
        Me.txtbankfaiz.Size = New System.Drawing.Size(192, 20)
        Me.txtbankfaiz.TabIndex = 7
        Me.txtbankfaiz.Text = ""
        '
        'txtbankaadi
        '
        Me.txtbankaadi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbankaadi.Location = New System.Drawing.Point(200, 32)
        Me.txtbankaadi.Name = "txtbankaadi"
        Me.txtbankaadi.Size = New System.Drawing.Size(192, 20)
        Me.txtbankaadi.TabIndex = 0
        Me.txtbankaadi.Text = ""
        '
        'Label74
        '
        Me.Label74.Location = New System.Drawing.Point(24, 56)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(176, 23)
        Me.Label74.TabIndex = 86
        Me.Label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txthesapno
        '
        Me.txthesapno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txthesapno.Location = New System.Drawing.Point(200, 56)
        Me.txthesapno.Name = "txthesapno"
        Me.txthesapno.Size = New System.Drawing.Size(192, 20)
        Me.txthesapno.TabIndex = 1
        Me.txthesapno.Text = ""
        '
        'Label75
        '
        Me.Label75.Location = New System.Drawing.Point(24, 32)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(176, 23)
        Me.Label75.TabIndex = 83
        Me.Label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label76
        '
        Me.Label76.Location = New System.Drawing.Point(24, 80)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(176, 23)
        Me.Label76.TabIndex = 87
        Me.Label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label69
        '
        Me.Label69.Location = New System.Drawing.Point(24, 224)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(176, 23)
        Me.Label69.TabIndex = 80
        Me.Label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtbankpincode
        '
        Me.txtbankpincode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbankpincode.Location = New System.Drawing.Point(200, 248)
        Me.txtbankpincode.Name = "txtbankpincode"
        Me.txtbankpincode.Size = New System.Drawing.Size(192, 20)
        Me.txtbankpincode.TabIndex = 9
        Me.txtbankpincode.Text = ""
        '
        'Label68
        '
        Me.Label68.Location = New System.Drawing.Point(24, 248)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(176, 23)
        Me.Label68.TabIndex = 82
        Me.Label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txthesapsahibi
        '
        Me.txthesapsahibi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txthesapsahibi.Location = New System.Drawing.Point(200, 224)
        Me.txthesapsahibi.Name = "txthesapsahibi"
        Me.txthesapsahibi.Size = New System.Drawing.Size(192, 20)
        Me.txthesapsahibi.TabIndex = 8
        Me.txthesapsahibi.Text = ""
        '
        'Label70
        '
        Me.Label70.Location = New System.Drawing.Point(24, 176)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(176, 23)
        Me.Label70.TabIndex = 78
        Me.Label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtbanktel
        '
        Me.txtbanktel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbanktel.Location = New System.Drawing.Point(200, 128)
        Me.txtbanktel.Name = "txtbanktel"
        Me.txtbanktel.Size = New System.Drawing.Size(192, 20)
        Me.txtbanktel.TabIndex = 4
        Me.txtbanktel.Text = ""
        '
        'txtswift
        '
        Me.txtswift.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtswift.Location = New System.Drawing.Point(200, 176)
        Me.txtswift.Name = "txtswift"
        Me.txtswift.Size = New System.Drawing.Size(192, 20)
        Me.txtswift.TabIndex = 6
        Me.txtswift.Text = ""
        '
        'Label71
        '
        Me.Label71.Location = New System.Drawing.Point(24, 152)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(176, 23)
        Me.Label71.TabIndex = 76
        Me.Label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtbanksube
        '
        Me.txtbanksube.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtbanksube.Location = New System.Drawing.Point(200, 152)
        Me.txtbanksube.Name = "txtbanksube"
        Me.txtbanksube.Size = New System.Drawing.Size(192, 20)
        Me.txtbanksube.TabIndex = 5
        Me.txtbanksube.Text = ""
        '
        'Label72
        '
        Me.Label72.Location = New System.Drawing.Point(24, 128)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(176, 23)
        Me.Label72.TabIndex = 74
        Me.Label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtyolno
        '
        Me.txtyolno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtyolno.Location = New System.Drawing.Point(200, 104)
        Me.txtyolno.Name = "txtyolno"
        Me.txtyolno.Size = New System.Drawing.Size(192, 20)
        Me.txtyolno.TabIndex = 3
        Me.txtyolno.Text = ""
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.txtextra10)
        Me.TabPage8.Controls.Add(Me.txtextra11)
        Me.TabPage8.Controls.Add(Me.txtextra12)
        Me.TabPage8.Controls.Add(Me.Label81)
        Me.TabPage8.Controls.Add(Me.Label82)
        Me.TabPage8.Controls.Add(Me.Label83)
        Me.TabPage8.Controls.Add(Me.txtextra7)
        Me.TabPage8.Controls.Add(Me.txtextra8)
        Me.TabPage8.Controls.Add(Me.txtextra9)
        Me.TabPage8.Controls.Add(Me.Label84)
        Me.TabPage8.Controls.Add(Me.Label85)
        Me.TabPage8.Controls.Add(Me.Label86)
        Me.TabPage8.Controls.Add(Me.txtextra4)
        Me.TabPage8.Controls.Add(Me.txtextra5)
        Me.TabPage8.Controls.Add(Me.txtextra6)
        Me.TabPage8.Controls.Add(Me.Label78)
        Me.TabPage8.Controls.Add(Me.Label79)
        Me.TabPage8.Controls.Add(Me.Label80)
        Me.TabPage8.Controls.Add(Me.txtextra1)
        Me.TabPage8.Controls.Add(Me.txtextra2)
        Me.TabPage8.Controls.Add(Me.txtextra3)
        Me.TabPage8.Controls.Add(Me.Label29)
        Me.TabPage8.Controls.Add(Me.Label30)
        Me.TabPage8.Controls.Add(Me.Label31)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(628, 370)
        Me.TabPage8.TabIndex = 5
        '
        'txtextra10
        '
        Me.txtextra10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtextra10.Location = New System.Drawing.Point(396, 176)
        Me.txtextra10.Multiline = True
        Me.txtextra10.Name = "txtextra10"
        Me.txtextra10.Size = New System.Drawing.Size(192, 48)
        Me.txtextra10.TabIndex = 9
        Me.txtextra10.Text = ""
        '
        'txtextra11
        '
        Me.txtextra11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtextra11.Location = New System.Drawing.Point(396, 232)
        Me.txtextra11.Multiline = True
        Me.txtextra11.Name = "txtextra11"
        Me.txtextra11.Size = New System.Drawing.Size(192, 48)
        Me.txtextra11.TabIndex = 10
        Me.txtextra11.Text = ""
        '
        'txtextra12
        '
        Me.txtextra12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtextra12.Location = New System.Drawing.Point(396, 288)
        Me.txtextra12.Multiline = True
        Me.txtextra12.Name = "txtextra12"
        Me.txtextra12.Size = New System.Drawing.Size(192, 48)
        Me.txtextra12.TabIndex = 11
        Me.txtextra12.Text = ""
        '
        'Label81
        '
        Me.Label81.Location = New System.Drawing.Point(328, 176)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(68, 23)
        Me.Label81.TabIndex = 80
        Me.Label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label82
        '
        Me.Label82.Location = New System.Drawing.Point(328, 232)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(68, 23)
        Me.Label82.TabIndex = 81
        Me.Label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label83
        '
        Me.Label83.Location = New System.Drawing.Point(328, 288)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(68, 23)
        Me.Label83.TabIndex = 82
        Me.Label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtextra7
        '
        Me.txtextra7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtextra7.Location = New System.Drawing.Point(396, 8)
        Me.txtextra7.Multiline = True
        Me.txtextra7.Name = "txtextra7"
        Me.txtextra7.Size = New System.Drawing.Size(192, 48)
        Me.txtextra7.TabIndex = 6
        Me.txtextra7.Text = ""
        '
        'txtextra8
        '
        Me.txtextra8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtextra8.Location = New System.Drawing.Point(396, 64)
        Me.txtextra8.Multiline = True
        Me.txtextra8.Name = "txtextra8"
        Me.txtextra8.Size = New System.Drawing.Size(192, 48)
        Me.txtextra8.TabIndex = 7
        Me.txtextra8.Text = ""
        '
        'txtextra9
        '
        Me.txtextra9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtextra9.Location = New System.Drawing.Point(396, 120)
        Me.txtextra9.Multiline = True
        Me.txtextra9.Name = "txtextra9"
        Me.txtextra9.Size = New System.Drawing.Size(192, 48)
        Me.txtextra9.TabIndex = 8
        Me.txtextra9.Text = ""
        '
        'Label84
        '
        Me.Label84.Location = New System.Drawing.Point(328, 8)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(68, 23)
        Me.Label84.TabIndex = 74
        Me.Label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label85
        '
        Me.Label85.Location = New System.Drawing.Point(328, 64)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(68, 23)
        Me.Label85.TabIndex = 75
        Me.Label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label86
        '
        Me.Label86.Location = New System.Drawing.Point(328, 120)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(68, 23)
        Me.Label86.TabIndex = 76
        Me.Label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtextra4
        '
        Me.txtextra4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtextra4.Location = New System.Drawing.Point(68, 176)
        Me.txtextra4.Multiline = True
        Me.txtextra4.Name = "txtextra4"
        Me.txtextra4.Size = New System.Drawing.Size(192, 48)
        Me.txtextra4.TabIndex = 3
        Me.txtextra4.Text = ""
        '
        'txtextra5
        '
        Me.txtextra5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtextra5.Location = New System.Drawing.Point(68, 232)
        Me.txtextra5.Multiline = True
        Me.txtextra5.Name = "txtextra5"
        Me.txtextra5.Size = New System.Drawing.Size(192, 48)
        Me.txtextra5.TabIndex = 4
        Me.txtextra5.Text = ""
        '
        'txtextra6
        '
        Me.txtextra6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtextra6.Location = New System.Drawing.Point(68, 288)
        Me.txtextra6.Multiline = True
        Me.txtextra6.Name = "txtextra6"
        Me.txtextra6.Size = New System.Drawing.Size(192, 48)
        Me.txtextra6.TabIndex = 5
        Me.txtextra6.Text = ""
        '
        'Label78
        '
        Me.Label78.Location = New System.Drawing.Point(4, 176)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(64, 23)
        Me.Label78.TabIndex = 68
        Me.Label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label79
        '
        Me.Label79.Location = New System.Drawing.Point(4, 232)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(64, 23)
        Me.Label79.TabIndex = 69
        Me.Label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label80
        '
        Me.Label80.Location = New System.Drawing.Point(4, 288)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(64, 23)
        Me.Label80.TabIndex = 70
        Me.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtextra1
        '
        Me.txtextra1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtextra1.Location = New System.Drawing.Point(68, 8)
        Me.txtextra1.Multiline = True
        Me.txtextra1.Name = "txtextra1"
        Me.txtextra1.Size = New System.Drawing.Size(192, 48)
        Me.txtextra1.TabIndex = 0
        Me.txtextra1.Text = ""
        '
        'txtextra2
        '
        Me.txtextra2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtextra2.Location = New System.Drawing.Point(68, 64)
        Me.txtextra2.Multiline = True
        Me.txtextra2.Name = "txtextra2"
        Me.txtextra2.Size = New System.Drawing.Size(192, 48)
        Me.txtextra2.TabIndex = 1
        Me.txtextra2.Text = ""
        '
        'txtextra3
        '
        Me.txtextra3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtextra3.Location = New System.Drawing.Point(68, 120)
        Me.txtextra3.Multiline = True
        Me.txtextra3.Name = "txtextra3"
        Me.txtextra3.Size = New System.Drawing.Size(192, 48)
        Me.txtextra3.TabIndex = 2
        Me.txtextra3.Text = ""
        '
        'Label29
        '
        Me.Label29.Location = New System.Drawing.Point(4, 8)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(64, 23)
        Me.Label29.TabIndex = 62
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label30
        '
        Me.Label30.Location = New System.Drawing.Point(4, 64)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(64, 23)
        Me.Label30.TabIndex = 63
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label31
        '
        Me.Label31.Location = New System.Drawing.Point(4, 120)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(64, 23)
        Me.Label31.TabIndex = 64
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.GroupBox6)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Size = New System.Drawing.Size(628, 370)
        Me.TabPage9.TabIndex = 6
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label25)
        Me.GroupBox6.Controls.Add(Me.txtgsc)
        Me.GroupBox6.Controls.Add(Me.Label26)
        Me.GroupBox6.Controls.Add(Me.txtgizlisoru)
        Me.GroupBox6.Controls.Add(Me.Label5)
        Me.GroupBox6.Controls.Add(Me.txtnickname)
        Me.GroupBox6.Controls.Add(Me.txtsifre)
        Me.GroupBox6.Controls.Add(Me.Label6)
        Me.GroupBox6.Location = New System.Drawing.Point(76, 88)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(448, 180)
        Me.GroupBox6.TabIndex = 53
        Me.GroupBox6.TabStop = False
        '
        'Label25
        '
        Me.Label25.Location = New System.Drawing.Point(44, 92)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(152, 23)
        Me.Label25.TabIndex = 50
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtgsc
        '
        Me.txtgsc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtgsc.Location = New System.Drawing.Point(204, 116)
        Me.txtgsc.Name = "txtgsc"
        Me.txtgsc.Size = New System.Drawing.Size(192, 20)
        Me.txtgsc.TabIndex = 3
        Me.txtgsc.Text = ""
        '
        'Label26
        '
        Me.Label26.Location = New System.Drawing.Point(44, 116)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(152, 23)
        Me.Label26.TabIndex = 52
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtgizlisoru
        '
        Me.txtgizlisoru.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtgizlisoru.Location = New System.Drawing.Point(204, 92)
        Me.txtgizlisoru.Name = "txtgizlisoru"
        Me.txtgizlisoru.Size = New System.Drawing.Size(192, 20)
        Me.txtgizlisoru.TabIndex = 2
        Me.txtgizlisoru.Text = ""
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(44, 44)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(152, 23)
        Me.Label5.TabIndex = 10
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtnickname
        '
        Me.txtnickname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtnickname.Location = New System.Drawing.Point(204, 44)
        Me.txtnickname.Name = "txtnickname"
        Me.txtnickname.Size = New System.Drawing.Size(192, 20)
        Me.txtnickname.TabIndex = 0
        Me.txtnickname.Text = ""
        '
        'txtsifre
        '
        Me.txtsifre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtsifre.Location = New System.Drawing.Point(204, 68)
        Me.txtsifre.Name = "txtsifre"
        Me.txtsifre.Size = New System.Drawing.Size(192, 20)
        Me.txtsifre.TabIndex = 1
        Me.txtsifre.Text = ""
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(44, 68)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(152, 23)
        Me.Label6.TabIndex = 12
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btndegistir
        '
        Me.btndegistir.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndegistir.Location = New System.Drawing.Point(420, 400)
        Me.btndegistir.Name = "btndegistir"
        Me.btndegistir.Size = New System.Drawing.Size(108, 23)
        Me.btndegistir.TabIndex = 3
        '
        'btnsil
        '
        Me.btnsil.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsil.Location = New System.Drawing.Point(84, 400)
        Me.btnsil.Name = "btnsil"
        Me.btnsil.Size = New System.Drawing.Size(108, 23)
        Me.btnsil.TabIndex = 0
        '
        'btnkaydet
        '
        Me.btnkaydet.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnkaydet.Location = New System.Drawing.Point(308, 400)
        Me.btnkaydet.Name = "btnkaydet"
        Me.btnkaydet.Size = New System.Drawing.Size(108, 23)
        Me.btnkaydet.TabIndex = 2
        '
        'btntemizle
        '
        Me.btntemizle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btntemizle.Location = New System.Drawing.Point(196, 400)
        Me.btntemizle.Name = "btntemizle"
        Me.btntemizle.Size = New System.Drawing.Size(108, 23)
        Me.btntemizle.TabIndex = 1
        '
        'nodi
        '
        Me.nodi.ContextMenu = Me.ContextMenu1
        Me.nodi.Icon = CType(resources.GetObject("nodi.Icon"), System.Drawing.Icon)
        Me.nodi.Text = ""
        Me.nodi.Visible = True
        '
        'ContextMenu1
        '
        Me.ContextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.Text = "Open"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.Text = "Exit"
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 1000
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem3, Me.MenuItem5, Me.MenuItem11, Me.MenuItem8})
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 0
        Me.MenuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem4})
        Me.MenuItem3.Text = "File"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 0
        Me.MenuItem4.Text = "Exit"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 1
        Me.MenuItem5.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem6, Me.MenuItem7})
        Me.MenuItem5.Text = "Language"
        '
        'MenuItem6
        '
        Me.MenuItem6.Checked = True
        Me.MenuItem6.Index = 0
        Me.MenuItem6.Text = "English"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 1
        Me.MenuItem7.Text = "Turkish"
        '
        'MenuItem11
        '
        Me.MenuItem11.Index = 2
        Me.MenuItem11.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem12})
        Me.MenuItem11.Text = "Properties"
        '
        'MenuItem12
        '
        Me.MenuItem12.Checked = True
        Me.MenuItem12.Index = 0
        Me.MenuItem12.Text = "Top Most"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 3
        Me.MenuItem8.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem9, Me.MenuItem10})
        Me.MenuItem8.Text = "Help"
        '
        'MenuItem9
        '
        Me.MenuItem9.Index = 0
        Me.MenuItem9.Text = "Help Form"
        '
        'MenuItem10
        '
        Me.MenuItem10.Index = 1
        Me.MenuItem10.Text = "About"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 13)
        Me.ClientSize = New System.Drawing.Size(644, 477)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximumSize = New System.Drawing.Size(652, 504)
        Me.Menu = Me.MainMenu1
        Me.MinimumSize = New System.Drawing.Size(652, 504)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "robo form"
        Me.TopMost = True
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabControl3.ResumeLayout(False)
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage11.ResumeLayout(False)
        Me.TabPage12.ResumeLayout(False)
        Me.TabPage13.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage9.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
#Region "API function"
    Public Declare Function SetActiveWindow Lib "user32" Alias "SetActiveWindow" _
    (ByVal hwnd As Long) As Long

    Declare Function keybd_event Lib "user32" Alias "keybd_event" _
    (ByVal bVk As Byte, ByVal bScan _
    As Byte, ByVal dwFlags As Long, ByVal dwExtraInfo As Long) As Long
#End Region
#Region "constraints"
    Const KEYEVENTF_KEYUP = &H2 ' Release key 
    Const VK_TAB = &H9      'tab        
    Const VK_RETURN = &HD   'enter
    Const VK_CONTROL = &H11     'ctrl
    Const VK_V = &H56   'v
#End Region
#Region "Global"
    Dim boylebirivar As Boolean
#End Region
#Region "button save"
    Private Sub btnkaydet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnkaydet.Click
        Try
            If txtprofiladi.Text = Nothing Then
                txtprofiladi.BackColor = Color.Red
                If MenuItem6.Checked = True Then
                    MsgBox("Please fill in the 'profiles name' field.")
                Else
                    MsgBox("Lutfen 'Profil adi' bolumunu doldurunuz.")
                End If
                txtprofiladi.BackColor = Color.White
                Exit Sub
            End If

            kontrol()             '    boyle biri varm�? 

            If boylebirivar = True Then
                Exit Sub
            Else
                Dim connstr As String
                connstr = "Provider=Microsoft.jet.oledb.4.0;data source=vt.mdb;Jet OLEDB:Database Password=123456789;"
                Dim conn As New OleDbConnection(connstr)
                conn.Open()
                Dim comm As New OleDbCommand
                With comm
                    .Connection = conn
                    .CommandType = CommandType.Text
                    .CommandText = "INSERT INTO [tbl_sablon]([profil_Adi], [nick_Name],[sifre], [e_Mail],[alternatif_e_Mail], [ad], [ikinci_Ad], [soyad], [dogum_Tarihi], [yas], [cinsiyet], [medeni_Durum], [ev_Adres], [is_Adres], [ev_Tel], [is_Tel], [posta_Kodu], [ulke], [ulke_Kodu], [sehir], [sehir_kodu], [ilce], [ilce_Kodu], [gizli_Soru], [gizli_Sorunun_cevabi], [hobi], [ozgecmis], [extra_Notlar_1], [extra_Notlar_2], [extra_Notlar_3], [extra_Notlar_4], [extra_Notlar_5], [extra_Notlar_6], [extra_Notlar_7], [extra_Notlar_8], [extra_Notlar_9], [extra_Notlar_10], [extra_Notlar_11], [extra_Notlar_12],[unvan],[meslek],[adres_Diger],[telefon],[faks_No],[cagri_No],[msn_Id],[yahoo_Id],[icq_No],[vergi_Kimligi],[gelir],[surucu_Lisansi],[web_Sayfam],[dogum_Yeri_il],[dogum_Yeri_ilce],[dogum_Yeri_diger],[sirket_adi],[bolum],[ucretsiz_Telefon],[web_Sitesi],[sirket_Kayit_no],[sirket_Vergi_id],[stok_Simgesi],[sirket_Santral_no],[sirket_Hakkinda],[kart_Turu],[kart_No],[kart_Onay_kod],[kart_Sure_bitimi],[kart_Gecerlilik],[kart_Kullanici_adi],[kart_Dagitici_banka],[kart_Banka_telefonu],[kart_Genel_servis],[kart_Pin_kodu],[kart_Limiti],[kart_Faiz_orani],[banka_Adi],[bank_Hesap_no],[bank_Hesap_turu],[bank_Yol_no],[bank_Tel],[bank_Sube],[bank_Swift],[bank_Faiz],[bank_Hesap_sahibi],[bank_Pin_code]) VALUES('" & txtprofiladi.Text & "' ,'" & txtnickname.Text & "','" & txtsifre.Text & "','" & txtemail.Text & "','" & txtaltemail.Text & "','" & txtad.Text & "','" & txtikinciad.Text & "','" & txtsoyad.Text & "','" & txtdogumtarihi.Text & "', '" & txtyas.Text & "','" & txtcinsiyet.Text & "','" & txtmd.Text & "','" & txtevadres.Text & "','" & txtisadres.Text & "','" & txtevtelefonu.Text & "','" & txtistelefonu.Text & "','" & txtpostakodu.Text & "','" & txtulke.Text & "','" & txtulkekodu.Text & "','" & txtsehir.Text & "','" & txtsehirkodu.Text & "','" & txtilce.Text & "','" & txtilcekodu.Text & "','" & txtgizlisoru.Text & "','" & txtgsc.Text & "','" & txthobi.Text & "','" & txtozgecmis.Text & "','" & txtextra1.Text & "','" & txtextra2.Text & "','" & txtextra3.Text & "','" & txtextra4.Text & "','" & txtextra5.Text & "','" & txtextra6.Text & "','" & txtextra7.Text & "','" & txtextra8.Text & "','" & txtextra9.Text & "','" & txtextra10.Text & "','" & txtextra11.Text & "','" & txtextra12.Text & "','" & txtunvan.Text & "','" & txtmeslek.Text & "','" & txtadresdiger.Text & "','" & txttelefon.Text & "','" & txtfaks.Text & "','" & txtcagri.Text & "','" & txtmsnid.Text & "','" & txtyahooid.Text & "','" & txticqno.Text & "','" & txtvergikim.Text & "','" & txtgelir.Text & "','" & txtsuruculis.Text & "','" & txtwebsayfam.Text & "','" & cmbil.Text & "','" & cmbilce.Text & "','" & txtdigerdogyer.Text & "','" & txtsirketadi.Text & "','" & txtbolum.Text & "','" & txtucrtelefon.Text & "','" & txtwebsitesi.Text & "','" & txtsirkayno.Text & "','" & txtsirverid.Text & "','" & txtstoksim.Text & "','" & txtsantralno.Text & "','" & txtsirhakkinda.Text & "','" & cmbkartturu.Text & "','" & txtkartno.Text & "','" & txtonaykod.Text & "','" & txtsurebitimi.Text & "','" & txtgecerlilik.Text & "','" & txtkartkuladi.Text & "','" & txtdagiticibanka.Text & "','" & txtbankatelefonu.Text & "','" & txtgenelserno.Text & "','" & txtpinkodu.Text & "','" & txtkredilimiti.Text & "','" & txtfaizorani.Text & "','" & txtbankaadi.Text & "','" & txthesapno.Text & "','" & cmbhesapturu.Text & "','" & txtyolno.Text & "','" & txtbanktel.Text & "','" & txtbanksube.Text & "','" & txtswift.Text & "','" & txtbankfaiz.Text & "','" & txthesapsahibi.Text & "','" & txtbankpincode.Text & "')"
                End With
                comm.ExecuteNonQuery()
                conn.Close()
                boylebirivar = False
                If MenuItem6.Checked = True Then
                    MsgBox("Saved successful")
                Else
                    MsgBox("Veriler basar�yla kaydedildi.")
                End If
            End If
            cmbprofil.Items.Clear()
            yukle()
        Catch ex As Exception
            MsgBox(ex.Message)
        Catch ex1 As OleDb.OleDbException
            MsgBox(ex1.Message)
        End Try
    End Sub
#End Region
#Region "button clear"
    Private Sub btntemizle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntemizle.Click
        formclear()
    End Sub
    Public Sub formclear()
        cmbil.SelectedItem = 0
        cmbilce.SelectedItem = 0
        cmbkartturu.SelectedItem = 0
        cmbhesapturu.SelectedItem = 0
        txtad.Text = Nothing
        txtaltemail.Text = Nothing
        txtcinsiyet.Text = Nothing
        txtdogumtarihi.Text = Nothing
        txtemail.Text = Nothing
        txtevadres.Text = Nothing
        txtevtelefonu.Text = Nothing
        txtextra1.Text = Nothing
        txtextra2.Text = Nothing
        txtextra3.Text = Nothing
        txtgizlisoru.Text = Nothing
        txtgsc.Text = Nothing
        txthobi.Text = Nothing
        txtikinciad.Text = Nothing
        txtilce.Text = Nothing
        txtilcekodu.Text = Nothing
        txtisadres.Text = Nothing
        txtilce.Text = Nothing
        txtilcekodu.Text = Nothing
        txtistelefonu.Text = Nothing
        txtmd.Text = Nothing
        txtnickname.Text = Nothing
        txtozgecmis.Text = Nothing
        txtpostakodu.Text = Nothing
        txtprofiladi.Text = Nothing
        txtsehir.Text = Nothing
        txtsehirkodu.Text = Nothing
        txtsifre.Text = Nothing
        txtsoyad.Text = Nothing
        txtulke.Text = Nothing
        txtulkekodu.Text = Nothing
        txtyas.Text = Nothing
        txtadresdiger.Text = Nothing
        txtbankaadi.Text = Nothing
        txtbankatelefonu.Text = Nothing
        txtbankfaiz.Text = Nothing
        txtbankpincode.Text = Nothing
        txtbanksube.Text = Nothing
        txtbanktel.Text = Nothing
        txtbolum.Text = Nothing
        txtcagri.Text = Nothing
        txtdagiticibanka.Text = Nothing
        txtdigerdogyer.Text = Nothing
        txtextra10.Text = Nothing
        txtextra11.Text = Nothing
        txtextra12.Text = Nothing
        txtextra4.Text = Nothing
        txtextra5.Text = Nothing
        txtextra6.Text = Nothing
        txtextra7.Text = Nothing
        txtextra8.Text = Nothing
        txtextra9.Text = Nothing
        txtfaizorani.Text = Nothing
        txtfaks.Text = Nothing
        txtgecerlilik.Text = Nothing
        txtgelir.Text = Nothing
        txtgenelserno.Text = Nothing
        txthesapno.Text = Nothing
        txthesapsahibi.Text = Nothing
        txticqno.Text = Nothing
        txtkartkuladi.Text = Nothing
        txtkartno.Text = Nothing
        txtkredilimiti.Text = Nothing
        txtmeslek.Text = Nothing
        txtmsnid.Text = Nothing
        txtonaykod.Text = Nothing
        txtpinkodu.Text = Nothing
        txtsantralno.Text = Nothing
        txtsirhakkinda.Text = Nothing
        txtsirkayno.Text = Nothing
        txtsirketadi.Text = Nothing
        txtsirverid.Text = Nothing
        txtstoksim.Text = Nothing
        txtsurebitimi.Text = Nothing
        txtsuruculis.Text = Nothing
        txtswift.Text = Nothing
        txttelefon.Text = Nothing
        txtucrtelefon.Text = Nothing
        txtunvan.Text = Nothing
        txtvergikim.Text = Nothing
        txtwebsayfam.Text = Nothing
        txtwebsitesi.Text = Nothing
        txtyahooid.Text = Nothing
        txtyolno.Text = Nothing
    End Sub
#End Region
#Region "button delete profile"
    Private Sub btnsil_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsil.Click
        Try
            If MenuItem6.Checked = True Then
                If MessageBox.Show("Do you want to delete " & txtprofiladi.Text & " ?", "QUEST�ON", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.Yes Then
                    deleteprofiles()
                Else
                End If
            Else
                If MessageBox.Show(txtprofiladi.Text & " adl� profili silmek istediginize eminmisiniz?", "QUEST�ON", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.Yes Then
                    deleteprofiles()
                Else
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Catch ex1 As OleDb.OleDbException
            MsgBox(ex1.Message)
        End Try
    End Sub
    Public Sub deleteprofiles()
        If txtprofiladi.Text = Nothing Then
            txtprofiladi.BackColor = Color.Red
            If MenuItem6.Checked = True Then
                MsgBox("Please fill in the 'profiles name' field.")
            Else
                MsgBox("Lutfen 'Profil adi' bolumune silmek istediginiz profil adini yaz�n�z")
            End If
            txtprofiladi.BackColor = Color.White
            Exit Sub
        End If
        Dim connstr As String
        connstr = "Provider=Microsoft.jet.oledb.4.0;data source=vt.mdb;Jet OLEDB:Database Password=123456789;"
        Dim conn As New OleDbConnection(connstr)
        conn.Open()
        Dim comm As New OleDbCommand
        With comm
            .Connection = conn
            .CommandType = CommandType.Text
            .CommandText = "DELETE FROM tbl_sablon WHERE profil_Adi= '" & txtprofiladi.Text & "'"
        End With
        comm.ExecuteNonQuery()
        conn.Close()
        If MenuItem6.Checked = True Then
            MsgBox("Deleted successful.")
        Else
            MsgBox("Kay�t basar�yla silindi.")
        End If
        cmbprofil.Items.Clear()
        yukle()
        formclear()
    End Sub
#End Region
#Region "button save changes"
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndegistir.Click
        Try
            If txtprofiladi.Text = Nothing Then
                txtprofiladi.BackColor = Color.Red
                If MenuItem6.Checked = True Then
                    MsgBox("Please fill in the 'profiles name' field.")
                Else
                    MsgBox("Lutfen 'Profil adi' bolumunu doldurunuz.")
                End If
                txtprofiladi.BackColor = Color.White
                Exit Sub
            End If
            Dim connstr As String
            connstr = "Provider=Microsoft.jet.oledb.4.0;data source=vt.mdb;Jet OLEDB:Database Password=123456789;"
            Dim conn As New OleDbConnection(connstr)
            conn.Open()
            Dim comm As New OleDbCommand
            With comm
                .Connection = conn
                .CommandType = CommandType.Text
                .CommandText = "UPDATE [tbl_sablon] SET [nick_Name]='" & txtnickname.Text & "', [sifre]='" & txtsifre.Text & "', [e_Mail]='" & txtemail.Text & "', [alternatif_e_Mail]='" & txtaltemail.Text & "', [ad]='" & txtad.Text & "', [ikinci_Ad]='" & txtikinciad.Text & "', [soyad]='" & txtsoyad.Text & "', [dogum_Tarihi]='" & txtdogumtarihi.Text & "', [yas]='" & txtyas.Text & "', [cinsiyet]='" & txtcinsiyet.Text & "', [medeni_Durum]='" & txtmd.Text & "', [ev_Adres]='" & txtevadres.Text & "', [is_Adres]='" & txtisadres.Text & "', [ev_Tel]='" & txtevtelefonu.Text & "', [is_Tel]='" & txtistelefonu.Text & "', [posta_Kodu]='" & txtpostakodu.Text & "', [ulke]='" & txtulke.Text & "', [ulke_Kodu]='" & txtulkekodu.Text & "', [sehir]='" & txtsehir.Text & "', [sehir_kodu]='" & txtsehirkodu.Text & "', [ilce]='" & txtilce.Text & "', [ilce_Kodu]='" & txtilcekodu.Text & "', [gizli_Soru]='" & txtgizlisoru.Text & "', [gizli_Sorunun_cevabi]='" & txtgsc.Text & "', [hobi]='" & txthobi.Text & "', [ozgecmis]='" & txtozgecmis.Text & "', [extra_Notlar_1]='" & txtextra1.Text & "', [extra_Notlar_2]='" & txtextra2.Text & "', [extra_Notlar_3]='" & txtextra3.Text & "', [extra_Notlar_4]='" & txtextra4.Text & "', [extra_Notlar_5]='" & txtextra5.Text & "', [extra_Notlar_6]='" & txtextra6.Text & "', [extra_Notlar_7]='" & txtextra7.Text & "', [extra_Notlar_8]='" & txtextra8.Text & "', [extra_Notlar_9]='" & txtextra9.Text & "', [extra_Notlar_10]='" & txtextra10.Text & "', [extra_Notlar_11]='" & txtextra11.Text & "', [extra_Notlar_12]='" & txtextra12.Text & "', [unvan]='" & txtunvan.Text & "', [meslek]='" & txtmeslek.Text & "', [adres_Diger]='" & txtadresdiger.Text & "', [telefon]='" & txttelefon.Text & "', [faks_No]='" & txtfaks.Text & "', [cagri_No]='" & txtcagri.Text & "', [msn_Id]='" & txtmsnid.Text & "', [yahoo_Id]='" & txtyahooid.Text & "', [icq_No]='" & txticqno.Text & "', [vergi_Kimligi]='" & txtvergikim.Text & "', [gelir]='" & txtgelir.Text & "', [surucu_Lisansi]='" & txtsuruculis.Text & "', [web_Sayfam]='" & txtwebsayfam.Text & "', [dogum_Yeri_il]='" & cmbil.Text & "', [dogum_Yeri_ilce]='" & cmbilce.Text & "', [dogum_Yeri_diger]='" & txtdigerdogyer.Text & "', [sirket_adi]='" & txtsirketadi.Text & "', [bolum]='" & txtbolum.Text & "', [ucretsiz_Telefon]='" & txtucrtelefon.Text & "', [web_Sitesi]='" & txtwebsitesi.Text & "', [sirket_Kayit_no]='" & txtsirkayno.Text & "', [sirket_Vergi_id]='" & txtsirverid.Text & "', [stok_Simgesi]='" & txtstoksim.Text & "', [sirket_Santral_no]='" & txtsantralno.Text & "', [sirket_Hakkinda]='" & txtsirhakkinda.Text & "', [kart_Turu]='" & cmbkartturu.Text & "', [kart_No]='" & txtkartno.Text & "', [kart_Onay_kod]='" & txtonaykod.Text & "', [kart_Sure_bitimi]='" & txtsurebitimi.Text & "', [kart_Gecerlilik]='" & txtgecerlilik.Text & "', [kart_Kullanici_adi]='" & txtkartkuladi.Text & "', [kart_Dagitici_banka]='" & txtdagiticibanka.Text & "', [kart_Banka_telefonu]='" & txtbankatelefonu.Text & "', [kart_Genel_servis]='" & txtgenelserno.Text & "', [kart_Pin_kodu]='" & txtpinkodu.Text & "', [kart_Limiti]='" & txtkredilimiti.Text & "', [kart_Faiz_orani]='" & txtfaizorani.Text & "', [banka_Adi]='" & txtbankaadi.Text & "', [bank_Hesap_no]='" & txthesapno.Text & "', [bank_Hesap_turu]='" & cmbhesapturu.Text & "', [bank_Yol_no]='" & txtyolno.Text & "', [bank_Tel]='" & txtbanktel.Text & "', [bank_Sube]='" & txtbanksube.Text & "', [bank_Swift]='" & txtswift.Text & "', [bank_Faiz]='" & txtbankfaiz.Text & "', [bank_Hesap_sahibi]='" & txthesapsahibi.Text & "', [bank_Pin_code]='" & txtbankpincode.Text & "' WHERE profil_Adi= '" & txtprofiladi.Text & "'"
            End With
            comm.ExecuteNonQuery()
            conn.Close()
            If MenuItem6.Checked = True Then
                MsgBox("Changed successful.")
            Else
                MsgBox("Kay�t basar�yla degistirlidi.")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Catch ex1 As OleDb.OleDbException
            MsgBox(ex1.Message)
        End Try
    End Sub
#End Region
#Region "form load "
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            textyaz()
            ililcecombodoldur()
            yukle()
            acctype()
        Catch ex As Exception
            MsgBox(ex.Message)
        Catch ex1 As OleDb.OleDbException
            MsgBox(ex1.Message)
        End Try
    End Sub
    Public Sub ililcecombodoldur()
        Try
            Dim getir As New il_ve_ilce.turkiye.il
            For i As Integer = 0 To getir.il_sayisi("iller.xml") - 1
                cmbil.Items.Add(getir.illerin_adlari(i, "iller.xml"))
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Public Sub yukle()
        Try
            Dim connstr As String
            connstr = "Provider=Microsoft.jet.oledb.4.0;data source=vt.mdb;Jet OLEDB:Database Password=123456789;"
            Dim conn As New OleDbConnection(connstr)
            Dim cmdSelect As OleDbCommand = New OleDbCommand("SELECT profil_Adi from tbl_sablon", conn)
            conn.Open()
            Dim dataReader As OleDbDataReader = cmdSelect.ExecuteReader
            Do While dataReader.Read
                cmbprofil.Items.Add(dataReader("profil_Adi"))
            Loop
            conn.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        Catch ex1 As OleDb.OleDbException
            MsgBox(ex1.Message)
        End Try
    End Sub
    Public Sub acctype()
        cmbhesapturu.Items.Clear()
        If MenuItem6.Checked = True Then
            cmbhesapturu.Items.Add("Checking")
            cmbhesapturu.Items.Add("Savings")
            cmbhesapturu.Items.Add("Money Manager")
            cmbhesapturu.Items.Add("Unlisted")
        Else
            cmbhesapturu.Items.Add("�ek")
            cmbhesapturu.Items.Add("Tasarruf")
            cmbhesapturu.Items.Add("Para Y�neticisi")
            cmbhesapturu.Items.Add("Diger")
        End If
    End Sub
#End Region
#Region "combo profile selected index change"
    Private Sub cmbprofil_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbprofil.SelectedIndexChanged
        Try
            If cmbprofil.SelectedItem = "Bir Profil Seciniz" Or cmbprofil.SelectedItem = Nothing Then
                Exit Sub
            Else
                lb1.Items.Clear()
                lb2.Items.Clear()
                lb3.Items.Clear()
                lb4.Items.Clear()
                txtprofiladi.Text = cmbprofil.SelectedItem
                Dim connstr As String
                connstr = "Provider=Microsoft.jet.oledb.4.0;data source=vt.mdb;Jet OLEDB:Database Password=123456789;"
                Dim conn As New OleDbConnection(connstr)
                conn.Open()
                Dim comm As New OleDbCommand
                With comm
                    .CommandType = CommandType.Text
                    .Connection = conn
                    .CommandText = "SELECT * FROM tbl_sablon"
                End With
                Dim dr As OleDbDataReader
                dr = comm.ExecuteReader
                While dr.Read
                    If cmbprofil.SelectedItem = dr("profil_Adi") Then
                        txtnickname.Text = dr("nick_Name")
                        listeyeekle(txtnickname.Text)
                        txtsifre.Text = dr("sifre")
                        listeyeekle(txtsifre.Text)
                        txtemail.Text = dr("e_Mail")
                        listeyeekle(txtemail.Text)
                        txtaltemail.Text = dr("alternatif_e_Mail")
                        listeyeekle(txtaltemail.Text)
                        txtad.Text = dr("ad")
                        listeyeekle(txtad.Text)
                        txtikinciad.Text = dr("ikinci_Ad")
                        listeyeekle(txtikinciad.Text)
                        txtsoyad.Text = dr("soyad")
                        listeyeekle(txtsoyad.Text)
                        txtdogumtarihi.Text = dr("dogum_Tarihi")
                        listeyeekle(txtdogumtarihi.Text)
                        txtyas.Text = dr("yas")
                        listeyeekle(txtyas.Text)
                        txtcinsiyet.Text = dr("cinsiyet")
                        listeyeekle(txtcinsiyet.Text)
                        txtmd.Text = dr("medeni_Durum")
                        listeyeekle(txtmd.Text)
                        txtevadres.Text = dr("ev_Adres")
                        listeyeekle(txtevadres.Text)
                        txtisadres.Text = dr("is_Adres")
                        listeyeekle(txtisadres.Text)
                        txtevtelefonu.Text = dr("ev_Tel")
                        listeyeekle(txtevtelefonu.Text)
                        txtistelefonu.Text = dr("is_Tel")
                        listeyeekle(txtistelefonu.Text)
                        txtpostakodu.Text = dr("posta_Kodu")
                        listeyeekle(txtpostakodu.Text)
                        txtulke.Text = dr("ulke")
                        listeyeekle(txtulke.Text)
                        txtulkekodu.Text = dr("ulke_Kodu")
                        listeyeekle(txtulkekodu.Text)
                        txtsehir.Text = dr("sehir")
                        listeyeekle(txtsehir.Text)
                        txtsehirkodu.Text = dr("sehir_kodu")
                        listeyeekle(txtsehirkodu.Text)
                        txtilce.Text = dr("ilce")
                        listeyeekle(txtilce.Text)
                        txtilcekodu.Text = dr("ilce_Kodu")
                        listeyeekle(txtilcekodu.Text)
                        txtgizlisoru.Text = dr("gizli_Soru")
                        listeyeekle(txtgizlisoru.Text)
                        txtgsc.Text = dr("gizli_Sorunun_cevabi")
                        listeyeekle(txtgsc.Text)
                        txthobi.Text = dr("hobi")
                        listeyeekle(txthobi.Text)
                        txtozgecmis.Text = dr("ozgecmis")
                        listeyeekle(txtozgecmis.Text)
                        txtextra1.Text = dr("extra_Notlar_1")
                        listeyeekle(txtextra1.Text)
                        txtextra2.Text = dr("extra_Notlar_2")
                        listeyeekle(txtextra2.Text)
                        txtextra3.Text = dr("extra_Notlar_3")
                        listeyeekle(txtextra3.Text)
                        txtextra4.Text = dr("extra_Notlar_4")
                        listeyeekle(txtextra4.Text)
                        txtextra5.Text = dr("extra_Notlar_5")
                        listeyeekle(txtextra5.Text)
                        txtextra6.Text = dr("extra_Notlar_6")
                        listeyeekle(txtextra6.Text)
                        txtextra7.Text = dr("extra_Notlar_7")
                        listeyeekle(txtextra7.Text)
                        txtextra8.Text = dr("extra_Notlar_8")
                        listeyeekle(txtextra8.Text)
                        txtextra9.Text = dr("extra_Notlar_9")
                        listeyeekle(txtextra9.Text)
                        txtextra10.Text = dr("extra_Notlar_10")
                        listeyeekle(txtextra10.Text)
                        txtextra11.Text = dr("extra_Notlar_11")
                        listeyeekle(txtextra11.Text)
                        txtextra12.Text = dr("extra_Notlar_12")
                        listeyeekle(txtextra12.Text)
                        txtunvan.Text = dr("unvan")
                        listeyeekle(txtunvan.Text)
                        txtmeslek.Text = dr("meslek")
                        listeyeekle(txtmeslek.Text)
                        txtadresdiger.Text = dr("adres_Diger")
                        listeyeekle(txtadresdiger.Text)
                        txttelefon.Text = dr("telefon")
                        listeyeekle(txttelefon.Text)
                        txtfaks.Text = dr("faks_No")
                        listeyeekle(txtfaks.Text)
                        txtcagri.Text = dr("cagri_No")
                        listeyeekle(txtcagri.Text)
                        txtmsnid.Text = dr("msn_Id")
                        listeyeekle(txtmsnid.Text)
                        txtyahooid.Text = dr("yahoo_Id")
                        listeyeekle(txtyahooid.Text)
                        txticqno.Text = dr("icq_No")
                        listeyeekle(txticqno.Text)
                        txtvergikim.Text = dr("vergi_Kimligi")
                        listeyeekle(txtvergikim.Text)
                        txtgelir.Text = dr("gelir")
                        listeyeekle(txtgelir.Text)
                        txtsuruculis.Text = dr("surucu_Lisansi")
                        listeyeekle(txtsuruculis.Text)
                        txtwebsayfam.Text = dr("web_Sayfam")
                        listeyeekle(txtwebsayfam.Text)
                        cmbil.Text = dr("dogum_Yeri_il")
                        listeyeekle(cmbil.Text)
                        cmbilce.Text = dr("dogum_Yeri_ilce")
                        listeyeekle(cmbilce.Text)
                        txtdigerdogyer.Text = dr("dogum_Yeri_diger")
                        listeyeekle(txtdigerdogyer.Text)
                        txtsirketadi.Text = dr("sirket_adi")
                        listeyeekle(txtsirketadi.Text)
                        txtbolum.Text = dr("bolum")
                        listeyeekle(txtbolum.Text)
                        txtucrtelefon.Text = dr("ucretsiz_Telefon")
                        listeyeekle(txtucrtelefon.Text)
                        txtwebsitesi.Text = dr("web_Sitesi")
                        listeyeekle(txtwebsitesi.Text)
                        txtsirkayno.Text = dr("sirket_Kayit_no")
                        listeyeekle(txtsirkayno.Text)
                        txtsirverid.Text = dr("sirket_Vergi_id")
                        listeyeekle(txtsirverid.Text)
                        txtstoksim.Text = dr("stok_Simgesi")
                        listeyeekle(txtstoksim.Text)
                        txtsantralno.Text = dr("sirket_Santral_no")
                        listeyeekle(txtsantralno.Text)
                        txtsirhakkinda.Text = dr("sirket_Hakkinda")
                        listeyeekle(txtsirhakkinda.Text)
                        cmbkartturu.Text = dr("kart_Turu")
                        listeyeekle(cmbkartturu.Text)
                        txtkartno.Text = dr("kart_No")
                        listeyeekle(txtkartno.Text)
                        txtonaykod.Text = dr("kart_Onay_kod")
                        listeyeekle(txtonaykod.Text)
                        txtsurebitimi.Text = dr("kart_Sure_bitimi")
                        listeyeekle(txtsurebitimi.Text)
                        txtgecerlilik.Text = dr("kart_Gecerlilik")
                        listeyeekle(txtgecerlilik.Text)
                        txtkartkuladi.Text = dr("kart_Kullanici_adi")
                        listeyeekle(txtkartkuladi.Text)
                        txtdagiticibanka.Text = dr("kart_Dagitici_banka")
                        listeyeekle(txtdagiticibanka.Text)
                        txtbankatelefonu.Text = dr("kart_Banka_telefonu")
                        listeyeekle(txtbankatelefonu.Text)
                        txtgenelserno.Text = dr("kart_Genel_servis")
                        listeyeekle(txtgenelserno.Text)
                        txtpinkodu.Text = dr("kart_Pin_kodu")
                        listeyeekle(txtpinkodu.Text)
                        txtkredilimiti.Text = dr("kart_Limiti")
                        listeyeekle(txtkredilimiti.Text)
                        txtfaizorani.Text = dr("kart_Faiz_orani")
                        listeyeekle(txtfaizorani.Text)
                        txtbankaadi.Text = dr("banka_Adi")
                        listeyeekle(txtbankaadi.Text)
                        txthesapno.Text = dr("bank_Hesap_no")
                        listeyeekle(txthesapno.Text)
                        cmbhesapturu.Text = dr("bank_Hesap_turu")
                        listeyeekle(cmbhesapturu.Text)
                        txtyolno.Text = dr("bank_Yol_no")
                        listeyeekle(txtyolno.Text)
                        txtbanktel.Text = dr("bank_Tel")
                        listeyeekle(txtbanktel.Text)
                        txtbanksube.Text = dr("bank_Sube")
                        listeyeekle(txtbanksube.Text)
                        txtswift.Text = dr("bank_Swift")
                        listeyeekle(txtswift.Text)
                        txtbankfaiz.Text = dr("bank_Faiz")
                        listeyeekle(txtbankfaiz.Text)
                        txthesapsahibi.Text = dr("bank_Hesap_sahibi")
                        listeyeekle(txthesapsahibi.Text)
                        txtbankpincode.Text = dr("bank_Pin_code")
                        listeyeekle(txtbankpincode.Text)
                    Else
                    End If
                End While
                comm.Dispose()
                conn.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Exit Sub
        Catch ex1 As OleDb.OleDbException
            MsgBox(ex1.Message)
            Exit Sub
        End Try
    End Sub
    Public Sub listeyeekle(ByVal deger As String)
        Try
            If deger = "" Or deger = Nothing Or deger = " " Then
            ElseIf deger.Length > 0 Then
                If lb1.Items.Count <= 25 Then
                    lb1.Items.Add(deger)
                Else
                    If lb2.Items.Count <= 25 Then
                        lb2.Items.Add(deger)
                    Else
                        If lb3.Items.Count <= 25 Then
                            lb3.Items.Add(deger)
                        Else
                            lb4.Items.Add(deger)
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
#End Region
#Region "control profile exists"
    Public Sub kontrol()
        Try
            Dim connstr As String
            connstr = "Provider=Microsoft.jet.oledb.4.0;data source=vt.mdb;Jet OLEDB:Database Password=123456789;"
            Dim conn As New OleDbConnection(connstr)
            conn.Open()
            Dim comm As New OleDbCommand
            With comm
                .CommandType = CommandType.Text
                .Connection = conn
                .CommandText = "SELECT * FROM tbl_sablon"
            End With
            Dim dr As OleDbDataReader
            dr = comm.ExecuteReader
            While dr.Read
                If dr("profil_Adi") = txtprofiladi.Text Then
                    boylebirivar = True
                    txtprofiladi.BackColor = Color.Red
                    If MenuItem6.Checked = True Then
                        MsgBox("This profile already exist")
                    Else
                        MsgBox("Boyle bir profil zaten mevcut, lutfen  'profil adi' bolumunu degistiriniz.")
                    End If
                    txtprofiladi.BackColor = Color.White
                    Exit Sub
                End If
            End While
        Catch ex As Exception
            MsgBox(ex.Message)
        Catch ex1 As OleDb.OleDbException
            MsgBox(ex1.Message)
        End Try
    End Sub
#End Region
#Region "listbox 1 ,2 ,3 ,4 double click"
    Private Sub lb1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lb1.DoubleClick
        Try
            If cb1.CheckState = CheckState.Checked And cb2.CheckState = CheckState.Checked Then
                Clipboard.SetDataObject(lb1.SelectedItem.ToString)
                SetActiveWindow(8975651603260375040)
                keybd_event(VK_CONTROL, 0, 0, 0)
                keybd_event(VK_V, 0, 0, 0)
                keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_TAB, 0, 0, 0)
                keybd_event(VK_TAB, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_RETURN, 0, 0, 0)
                keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0)
            ElseIf cb1.CheckState = CheckState.Checked Or cb2.CheckState = CheckState.Checked Then
                If cb1.CheckState = CheckState.Checked Then
                    Clipboard.SetDataObject(lb1.SelectedItem.ToString)
                    SetActiveWindow(8975651603260375040)
                    keybd_event(VK_CONTROL, 0, 0, 0)
                    keybd_event(VK_V, 0, 0, 0)
                    keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_TAB, 0, 0, 0)
                    keybd_event(VK_TAB, 0, KEYEVENTF_KEYUP, 0)
                Else
                    Clipboard.SetDataObject(lb1.SelectedItem.ToString)
                    SetActiveWindow(8975651603260375040)
                    keybd_event(VK_CONTROL, 0, 0, 0)
                    keybd_event(VK_V, 0, 0, 0)
                    keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_RETURN, 0, 0, 0)
                    keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0)
                End If
            Else
                Clipboard.SetDataObject(lb1.SelectedItem.ToString)
                SetActiveWindow(8975651603260375040)
                keybd_event(VK_CONTROL, 0, 0, 0)
                keybd_event(VK_V, 0, 0, 0)
                keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
            End If
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub lb2_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lb2.DoubleClick
        Try
            If cb1.CheckState = CheckState.Checked And cb2.CheckState = CheckState.Checked Then
                Clipboard.SetDataObject(lb2.SelectedItem.ToString)
                SetActiveWindow(8975651603260375040)
                keybd_event(VK_CONTROL, 0, 0, 0)
                keybd_event(VK_V, 0, 0, 0)
                keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_TAB, 0, 0, 0)
                keybd_event(VK_TAB, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_RETURN, 0, 0, 0)
                keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0)
            ElseIf cb1.CheckState = CheckState.Checked Or cb2.CheckState = CheckState.Checked Then
                If cb1.CheckState = CheckState.Checked Then
                    Clipboard.SetDataObject(lb2.SelectedItem.ToString)
                    SetActiveWindow(8975651603260375040)
                    keybd_event(VK_CONTROL, 0, 0, 0)
                    keybd_event(VK_V, 0, 0, 0)
                    keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_TAB, 0, 0, 0)
                    keybd_event(VK_TAB, 0, KEYEVENTF_KEYUP, 0)
                Else
                    Clipboard.SetDataObject(lb2.SelectedItem.ToString)
                    SetActiveWindow(8975651603260375040)
                    keybd_event(VK_CONTROL, 0, 0, 0)
                    keybd_event(VK_V, 0, 0, 0)
                    keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_RETURN, 0, 0, 0)
                    keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0)
                End If
            Else
                Clipboard.SetDataObject(lb2.SelectedItem.ToString)
                SetActiveWindow(8975651603260375040)
                keybd_event(VK_CONTROL, 0, 0, 0)
                keybd_event(VK_V, 0, 0, 0)
                keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
            End If
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub lb3_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lb3.DoubleClick
        Try
            If cb1.CheckState = CheckState.Checked And cb2.CheckState = CheckState.Checked Then
                Clipboard.SetDataObject(lb3.SelectedItem.ToString)
                SetActiveWindow(8975651603260375040)
                keybd_event(VK_CONTROL, 0, 0, 0)
                keybd_event(VK_V, 0, 0, 0)
                keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_TAB, 0, 0, 0)
                keybd_event(VK_TAB, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_RETURN, 0, 0, 0)
                keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0)
            ElseIf cb1.CheckState = CheckState.Checked Or cb2.CheckState = CheckState.Checked Then
                If cb1.CheckState = CheckState.Checked Then
                    Clipboard.SetDataObject(lb3.SelectedItem.ToString)
                    SetActiveWindow(8975651603260375040)
                    keybd_event(VK_CONTROL, 0, 0, 0)
                    keybd_event(VK_V, 0, 0, 0)
                    keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_TAB, 0, 0, 0)
                    keybd_event(VK_TAB, 0, KEYEVENTF_KEYUP, 0)
                Else
                    Clipboard.SetDataObject(lb3.SelectedItem.ToString)
                    SetActiveWindow(8975651603260375040)
                    keybd_event(VK_CONTROL, 0, 0, 0)
                    keybd_event(VK_V, 0, 0, 0)
                    keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_RETURN, 0, 0, 0)
                    keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0)
                End If
            Else
                Clipboard.SetDataObject(lb3.SelectedItem.ToString)
                SetActiveWindow(8975651603260375040)
                keybd_event(VK_CONTROL, 0, 0, 0)
                keybd_event(VK_V, 0, 0, 0)
                keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
            End If
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub lb4_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lb4.DoubleClick
        Try
            If cb1.CheckState = CheckState.Checked And cb2.CheckState = CheckState.Checked Then
                Clipboard.SetDataObject(lb4.SelectedItem.ToString)
                SetActiveWindow(8975651603260375040)
                keybd_event(VK_CONTROL, 0, 0, 0)
                keybd_event(VK_V, 0, 0, 0)
                keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_TAB, 0, 0, 0)
                keybd_event(VK_TAB, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_RETURN, 0, 0, 0)
                keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0)
            ElseIf cb1.CheckState = CheckState.Checked Or cb2.CheckState = CheckState.Checked Then
                If cb1.CheckState = CheckState.Checked Then
                    Clipboard.SetDataObject(lb4.SelectedItem.ToString)
                    SetActiveWindow(8975651603260375040)
                    keybd_event(VK_CONTROL, 0, 0, 0)
                    keybd_event(VK_V, 0, 0, 0)
                    keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_TAB, 0, 0, 0)
                    keybd_event(VK_TAB, 0, KEYEVENTF_KEYUP, 0)
                Else
                    Clipboard.SetDataObject(lb4.SelectedItem.ToString)
                    SetActiveWindow(8975651603260375040)
                    keybd_event(VK_CONTROL, 0, 0, 0)
                    keybd_event(VK_V, 0, 0, 0)
                    keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
                    keybd_event(VK_RETURN, 0, 0, 0)
                    keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0)
                End If
            Else
                Clipboard.SetDataObject(lb4.SelectedItem.ToString)
                SetActiveWindow(8975651603260375040)
                keybd_event(VK_CONTROL, 0, 0, 0)
                keybd_event(VK_V, 0, 0, 0)
                keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
                keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
            End If
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub
#End Region
#Region "button tab"
    Private Sub btntab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntab.Click
        Try
            SetActiveWindow(8975651603260375040)
            keybd_event(VK_TAB, 0, 0, 0)
            keybd_event(VK_TAB, 0, KEYEVENTF_KEYUP, 0)
        Catch ex As Exception
            MsgBox(ex.Message)
            Exit Sub
        End Try
    End Sub
#End Region
#Region "button enter"
    Private Sub btnenter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnenter.Click
        Try
            SetActiveWindow(8975651603260375040)
            keybd_event(VK_RETURN, 0, 0, 0)
            keybd_event(VK_RETURN, 0, KEYEVENTF_KEYUP, 0)
        Catch ex As Exception
            MsgBox(ex.Message)
            Exit Sub
        End Try
    End Sub
#End Region
#Region "nodify icon"
    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        If Me.WindowState = FormWindowState.Minimized Then
            nodi.Visible = True
            Me.Hide()
            Timer1.Enabled = True
        Else
            Me.Show()
            nodi.Visible = False
        End If
    End Sub

    Private Sub nodi_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles nodi.DoubleClick
        Me.Show()
        Me.WindowState = FormWindowState.Normal
        nodi.Visible = False
    End Sub

    Private Sub nodi_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles nodi.MouseMove
        nodi.Text = "Robo Form still running here." & vbCrLf & "Kullanilan profil : " & cmbprofil.SelectedItem
    End Sub
#End Region
#Region "Context Menu 1"
    Private Sub MenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem1.Click
        Me.Show()
        Me.WindowState = FormWindowState.Normal
        nodi.Visible = False
    End Sub

    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        Me.Close()
        Me.Dispose()
    End Sub
#End Region
#Region "combo il ve ilce for turkey"
    Private Sub cmbil_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbil.SelectedIndexChanged
        Try
            If cmbil.Text <> Nothing Then
                cmbilce.Items.Clear()
                cmbilce.Text = Nothing
                Dim ilce As New il
                For i As Integer = 0 To ilce.ilce_sayisi(cmbil.SelectedItem.ToString, "iller.xml") - 1
                    cmbilce.Items.Add(ilce.ilceadlari(cmbil.SelectedItem.ToString, i, "iller.xml"))
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Exit Sub
        End Try
    End Sub
#End Region
#Region "other birth place check box"
    Private Sub chkdiger_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkdiger.CheckedChanged
        chkchange()
    End Sub
    Public Sub chkchange()
        If chkdiger.CheckState = CheckState.Checked Then
            cmbil.Enabled = False
            cmbilce.Enabled = False
            txtdigerdogyer.Enabled = True
        Else
            cmbil.Enabled = True
            cmbilce.Enabled = True
            txtdigerdogyer.Enabled = False
        End If
    End Sub
#End Region
#Region "icon visible change"
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Static sayac As Integer
        If Me.WindowState = FormWindowState.Minimized Then
            sayac += 1
            If sayac <= 5 Then
                nodi.Visible = Not nodi.Visible
            Else
                nodi.Visible = True
                Timer1.Enabled = False
            End If
        Else
            nodi.Visible = False
            Timer1.Enabled = False
            Exit Sub
        End If
    End Sub
#End Region
#Region "timer 2 tick"
    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Try
            Timer1.Enabled = False
            Static formacilis As Integer
            formacilis += 1
            If formacilis >= 3 Then
                Me.WindowState = FormWindowState.Normal
                Me.Show()
                Timer2.Enabled = False
            End If
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub
#End Region
#Region "fill texts of labels"
    Public Sub textyaz()
        tabcontrol(Me.TabControl1)
        tabcontrol(Me.TabControl2)
        tabcontrol(Me.TabControl3)
        grpcontrol(Me.GroupBox1)
        grpcontrol(Me.GroupBox2)
        grpcontrol(Me.GroupBox3)
        grpcontrol(Me.GroupBox4)
        grpcontrol(Me.GroupBox5)
        grpcontrol(Me.GroupBox6)
    End Sub
    Public Function tabcontrol(ByVal tablar As tabcontrol)
        Dim tp As TabPage
        For Each tp In tablar.TabPages
            conttextyaz(tp)
            For Each cont As Control In tp.Controls
                conttextyaz(cont)
            Next
        Next
    End Function
    Public Function grpcontrol(ByVal grp As GroupBox)
        Dim gb As GroupBox
        For Each cont As Control In grp.Controls
            conttextyaz(cont)
        Next
    End Function
    Public Sub conttextyaz(ByVal c As Control)
        If MenuItem6.Checked = True Then
            Dim tr As New XmlTextReader("english.xml")
            While tr.Read
                If tr.Name = "control" Then
                    If c.Name = tr.GetAttribute("name") Then
                        c.Text = tr.ReadElementString
                    End If
                End If
            End While
            tr.Close()
        Else
            Dim tr As New XmlTextReader("turkish.xml")
            While tr.Read
                If tr.Name = "control" Then
                    If c.Name = tr.GetAttribute("name") Then
                        c.Text = tr.ReadElementString
                    End If
                End If
            End While
            tr.Close()
        End If
    End Sub
#End Region
#Region "me dispose & application exit"
    Private Sub Form1_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.Dispose()
        Application.Exit()
    End Sub
#End Region
#Region "main menu"
    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem4.Click
        Me.Dispose()
        Application.Exit()
    End Sub

    Private Sub MenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem6.Click
        MenuItem6.Checked = Not MenuItem6.Checked
        If MenuItem6.Checked = True Then
            MenuItem7.Checked = False
            chkdiger.CheckState = CheckState.Checked
        Else
            MenuItem7.Checked = True
            chkdiger.CheckState = CheckState.Unchecked
        End If
        textyaz()
        acctype()
        chkchange()
    End Sub

    Private Sub MenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem7.Click
        MenuItem7.Checked = Not MenuItem7.Checked
        If MenuItem7.Checked = True Then
            MenuItem6.Checked = False
            chkdiger.CheckState = CheckState.Unchecked
        Else
            MenuItem6.Checked = True
            chkdiger.CheckState = CheckState.Checked
        End If
        textyaz()
        acctype()
        chkchange()
    End Sub

    Private Sub MenuItem12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem12.Click
        MenuItem12.Checked = Not MenuItem12.Checked
        If MenuItem12.Checked = True Then
            Me.TopMost = True
        Else
            Me.TopMost = False
        End If
    End Sub

    Private Sub MenuItem9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem9.Click
        Dim hf As New help
        hf.Show()
    End Sub

    Private Sub MenuItem10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem10.Click
        Dim inf As New info
        inf.ShowDialog()
    End Sub
#End Region

End Class
