Imports AxWMPLib
Public Class info
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ContextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ContextMenu1 = New System.Windows.Forms.ContextMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.Black
        Me.TextBox1.ContextMenu = Me.ContextMenu1
        Me.TextBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox1.Font = New System.Drawing.Font("Impact", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.TextBox1.ForeColor = System.Drawing.Color.White
        Me.TextBox1.Location = New System.Drawing.Point(0, 0)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(288, 285)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = ""
        '
        'Timer1
        '
        Me.Timer1.Interval = 200
        '
        'ContextMenu1
        '
        Me.ContextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.Text = "Exit"
        '
        'info
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(288, 285)
        Me.Controls.Add(Me.TextBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximumSize = New System.Drawing.Size(288, 285)
        Me.MinimumSize = New System.Drawing.Size(288, 285)
        Me.Name = "info"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "info"
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub

#End Region
    Dim rnd, rnd2 As New Random
    Private Sub info_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
    End Sub
    Dim i As Integer
    Dim wmp As New WMPLib.WindowsMediaPlayer
    Dim s As Integer
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try
            Timer1.Interval = rnd.Next(50, 450)
            s = rnd2.Next(0, 3)
            i += 1
            Dim str As String
            str = " Roboform written by OZAN TEKBAS in 24/06/2005. Contact = ozzybard@yahoo.com.au" & vbCrLf & " This programme needs '.net framework'." & vbCrLf & " All labels gets text from xml document.You can change roboform's language if you want. " & vbCrLf & " Roboform fills member form, password field and nickname field quickly."
            If s = 0 Then
                wmp.URL = "typ2.wav"
            ElseIf s = 1 Then
                wmp.URL = "typ1.wav"
            ElseIf s = 2 Then
                wmp.URL = "typ0.wav"
            Else
            End If
            If i >= str.Length Then
                TextBox1.Text &= "." & vbCrLf
                Me.Close()
                Timer1.Enabled = False
            Else
                TextBox1.Text &= Mid(str, i, 1)
            End If
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub MenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem1.Click
        Timer1.Enabled = False
        Me.Close()
    End Sub
End Class
